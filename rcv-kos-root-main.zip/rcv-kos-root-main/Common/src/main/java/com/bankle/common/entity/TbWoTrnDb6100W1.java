package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_DB_6100_W1")
public class TbWoTrnDb6100W1 {
    @EmbeddedId
    private TbWoTrnDb6100W1Id id;

    @Column(name = "TG_LEN", precision = 8)
    private BigDecimal tgLen;

    @Size(max = 5)
    @Column(name = "TG_DSC", length = 5)
    private String tgDsc;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 5)
    @Column(name = "LND_AGNC_CD", length = 5)
    private String lndAgncCd;

    @Column(name = "BNK_TG_TRNS_DTM")
    private LocalDateTime bnkTgTrnsDtm;

    @Column(name = "DB_TG_TRNS_DTM")
    private LocalDateTime dbTgTrnsDtm;

    @Size(max = 8)
    @Column(name = "BNK_TG_NO", length = 8)
    private String bnkTgNo;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "DB_TG_NO", nullable = false, precision = 8)
    private BigDecimal dbTgNo;

    @Size(max = 39)
    @Column(name = "RSRV_ITM_H", length = 39)
    private String rsrvItmH;

    @Size(max = 20)
    @Column(name = "BNK_ASK_NO", length = 20)
    private String bnkAskNo;

    @Size(max = 20)
    @Column(name = "DB_MNG_NO", length = 20)
    private String dbMngNo;

    @Size(max = 14)
    @Column(name = "KOS_TG_TRNS_DTM", length = 14)
    private String kosTgTrnsDtm;

    @Size(max = 14)
    @Column(name = "KOS_TG_NO", length = 14)
    private String kosTgNo;

    @Size(max = 1)
    @Column(name = "PROC_DVSN_CD", length = 1)
    private String procDvsnCd;

    @Size(max = 1)
    @Column(name = "RTH_ISRN_ENTR_YN", length = 1)
    private String rthIsrnEntrYn;

    @Size(max = 1)
    @Column(name = "RTH_ISRN_ENTR_CMPY", length = 1)
    private String rthIsrnEntrCmpy;

    @Size(max = 30)
    @Column(name = "RTH_ISRN_SCRT_NO", length = 30)
    private String rthIsrnScrtNo;

    @Size(max = 6)
    @Column(name = "PST_NO", length = 6)
    private String pstNo;

    @Size(max = 10)
    @Column(name = "CRTDN_CD", length = 10)
    private String crtdnCd;

    @Size(max = 122)
    @Column(name = "TRGT_ADDR", length = 122)
    private String trgtAddr;

    @Size(max = 122)
    @Column(name = "TRGT_DTL_ADDR", length = 122)
    private String trgtDtlAddr;

    @Size(max = 20)
    @Column(name = "RGSTR_UNQ_NO_1", length = 20)
    private String rgstrUnqNo1;

    @Size(max = 20)
    @Column(name = "RGSTR_UNQ_NO_2", length = 20)
    private String rgstrUnqNo2;

    @Size(max = 20)
    @Column(name = "RGSTR_UNQ_NO_3", length = 20)
    private String rgstrUnqNo3;

    @Size(max = 2)
    @Column(name = "LND_KND_CD", length = 2)
    private String lndKndCd;

    @Size(max = 1)
    @Column(name = "FND_YN", length = 1)
    private String fndYn;

    @Size(max = 200)
    @Column(name = "PRDT_NM", length = 200)
    private String prdtNm;

    @Size(max = 20)
    @Column(name = "PRDT_CD", length = 20)
    private String prdtCd;

    @Size(max = 2)
    @Column(name = "GRNT_AGNC_CD", length = 2)
    private String grntAgncCd;

    @Size(max = 1)
    @Column(name = "SRV_TRGT_YN", length = 1)
    private String srvTrgtYn;

    @Size(max = 1)
    @Column(name = "STND_TRGT_YN", length = 1)
    private String stndTrgtYn;

    @Size(max = 1)
    @Column(name = "RRCP_CHRG_TRGT_YN", length = 1)
    private String rrcpChrgTrgtYn;

    @Size(max = 1)
    @Column(name = "RVSN_CNTRCT_CHRG_TRGT_YN", length = 1)
    private String rvsnCntrctChrgTrgtYn;

    @Size(max = 8)
    @Column(name = "SSCPT_ASK_DT", length = 8)
    private String sscptAskDt;

    @Size(max = 8)
    @Column(name = "LND_PLN_DT", length = 8)
    private String lndPlnDt;

    @Size(max = 8)
    @Column(name = "RNTL_PRD_END_DT", length = 8)
    private String rntlPrdEndDt;

    @Size(max = 8)
    @Column(name = "LND_EXPRD_DT", length = 8)
    private String lndExprdDt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "LND_PRD", nullable = false, precision = 3)
    private BigDecimal lndPrd;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "LND_AMT", nullable = false, precision = 15)
    private BigDecimal lndAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "ISRN_ENTR_AMT", nullable = false, precision = 15)
    private BigDecimal isrnEntrAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "OBJT_EBNK_RGSTR_RNK", nullable = false, precision = 20)
    private BigDecimal objtEbnkRgstrRnk;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "OBJT_EBNK_BND_MAX_AMT", nullable = false, precision = 50)
    private BigDecimal objtEbnkBndMaxAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "MGG_FNL_ODPRT_AMT", nullable = false, precision = 20)
    private BigDecimal mggFnlOdprtAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "TROL_FNL_ODPRT_AMT", nullable = false, precision = 20)
    private BigDecimal trolFnlOdprtAmt;

    @Size(max = 8)
    @Column(name = "SRVC_END_DT", length = 8)
    private String srvcEndDt;

    @Size(max = 52)
    @Column(name = "DBTR_NM", length = 52)
    private String dbtrNm;

    @Size(max = 13)
    @Column(name = "DBTR_RRNO", length = 13)
    private String dbtrRrno;

    @Size(max = 5)
    @Column(name = "DBTR_PST_NO", length = 5)
    private String dbtrPstNo;

    @Size(max = 244)
    @Column(name = "DBTR_ADDR", length = 244)
    private String dbtrAddr;

    @Size(max = 20)
    @Column(name = "DBTR_PHNO", length = 20)
    private String dbtrPhno;

    @Size(max = 20)
    @Column(name = "DBTR_HPNO", length = 20)
    private String dbtrHpno;

    @Size(max = 1)
    @Column(name = "WDNG_PLN_YN", length = 1)
    private String wdngPlnYn;

    @Size(max = 8)
    @Column(name = "WDNG_PLN_DT", length = 8)
    private String wdngPlnDt;

    @Size(max = 1)
    @Column(name = "HSHLDR_CNDDT_YN", length = 1)
    private String hshldrCnddtYn;

    @Size(max = 1)
    @Column(name = "UNMRD_HSHLDR_25AG_LSTN_YN", length = 1)
    private String unmrdHshldr25agLstnYn;

    @Size(max = 1)
    @Column(name = "ACPT_DSC", length = 1)
    private String acptDsc;

    @Size(max = 42)
    @Column(name = "LWFM_NM", length = 42)
    private String lwfmNm;

    @Size(max = 20)
    @Column(name = "LWFM_BIZNO", length = 20)
    private String lwfmBizno;

    @Size(max = 20)
    @Column(name = "ASK_BRNCH_CD", length = 20)
    private String askBrnchCd;

    @Size(max = 42)
    @Column(name = "ASK_BRNCH_NM", length = 42)
    private String askBrnchNm;

    @Size(max = 42)
    @Column(name = "ASK_BRNCH_DRCTR_NM", length = 42)
    private String askBrnchDrctrNm;

    @Size(max = 20)
    @Column(name = "ASK_BRNCH_PHNO", length = 20)
    private String askBrnchPhno;

    @Size(max = 2)
    @Column(name = "BNK_LES_DSC", length = 2)
    private String bnkLesDsc;

    @Size(max = 2)
    @Column(name = "FND_LES_DSC", length = 2)
    private String fndLesDsc;

    @Size(max = 100)
    @Column(name = "CNDTL_CNTS", length = 100)
    private String cndtlCnts;

    @Size(max = 15)
    @Column(name = "ISRN_PRMM", length = 15)
    private String isrnPrmm;

    @Size(max = 900)
    @Column(name = "RSRV_ITM_B", length = 900)
    private String rsrvItmB;

    @Column(name = "REG_DTM")
    private LocalDateTime regDtm;

    @Size(max = 20)
    @Column(name = "LOAN_APRV_NO_2", length = 20)
    private String loanAprvNo2;

}