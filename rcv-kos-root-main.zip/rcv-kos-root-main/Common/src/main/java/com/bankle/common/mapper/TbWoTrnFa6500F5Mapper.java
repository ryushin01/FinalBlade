package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnFa6500F5Dto;
import com.bankle.common.entity.TbWoTrnFa6500F5;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TbWoTrnFa6500F5Mapper extends DefaultMapper<TbWoTrnFa6500F5Dto, TbWoTrnFa6500F5> {
    TbWoTrnFa6500F5Mapper INSTANCE = Mappers.getMapper(TbWoTrnFa6500F5Mapper.class);
}