package com.bankle.common.wooriApi.socket.ins.commonSvc.vo;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class InsCmnSvo {


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class insCmnInVo {

        @Schema(name = "전문일련번호")
        private String tgSqn;

        @Schema(name = "은행코드")
        private String bnkCd;

        @Schema(name = "전문구분코드")
        private String tgDsc;

        @Schema(name = "거래구분코드")
        private String trDsc;

        @Schema(name = "은행일련번호")
        private String bnkTgNo;

        @Schema(name = "전문요청일시")
        private LocalDateTime reqDtm;

        @Schema(name = "전문요청대상내용")
        private String reqTgCnts;

        @Schema(name = "전문요청대상로그")
        private String reqTgLog;

        @Schema(name = "전문요청대상기능여부")
        private String reqTgFnYn;

        @Schema(name = "전문응답일시")
        private LocalDateTime resDtm;

        @Schema(name = "전문응답대상내용")
        private String resTgCnts;

        @Schema(name = "전문응답대상로그")
        private String resTgLog;

        @Schema(name = "전문응답대상기능여부")
        private String resTgFnYn;

        @Schema(name = "전문요청대상")
        private String loanNo;

        @Schema(name = "전문요청대상")
        private String membNo;

        @Schema(name = "응답코드")
        private String resCd;

        @Schema(name = "응답메시지")
        private String resMsg;

        @Schema(name = "전송상태코드")
        private String trnsStc;

        @Schema(name = "변경일시")
        private LocalDateTime chgDtm;

        private String tgSndDtm;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class insResp6100InVo {

        @Schema(name = "보험사 구분")
        private String insDvsn;

        @Schema(name = "대표법무사 회원관리번호")
        private String reptMembNo;

        @Schema(name = "여신번호")
        private String loanNo;

        @Schema(name = "법무사 사업자 번호")
        private String lwfwBizNo;
    }
}
