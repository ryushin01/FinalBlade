package com.bankle.common.wooriApi.socket.ins.sendSvc;

import com.bankle.common.exception.DefaultException;
import com.bankle.common.repo.TbWoTrnFa6500F5Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.GetSetData;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6500F5Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6500F5;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.bankle.common.enums.Sequence;

import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import org.springframework.transaction.annotation.Propagation;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Slf4j
@Component
@RequiredArgsConstructor
public class Send6500F5Svc {

    private final TbWoTrnFa6500F5Repository tbWoTrnFa6500F5Repository;

    private final InsCmnSvc insCmnSvc;

    private final BizUtil bizUtil;

    private final String BNK_TG_DSC = "6500";
    private final String TG_DSC = "F5000";
    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    private final String TG_LEN = "3000";
    private final String BNK_TG_NO = "";
    private final String FA_TG_NO = "";
    private final String RES_CD = "";
    private final String RSRV_ITM_H = "";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final GetSetData getSetData;


    @Transactional
    public CheckResponseSvo sendAndResponse(@Valid Send6500F5Svo.sendInVo invo) throws Exception{
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo);
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo.getLoanNo());
        String seq = this.send(invo);
        log.debug("Send6500F5Svc.sendAndResponse().seq : " + seq);
        return insCmnSvc.checkResponse(seq);
    }

    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(Send6500F5Svo.sendInVo sendInVo) throws Exception {
        try {
            log.debug("Send6500F5Svc.send > sendInVo : " + sendInVo);
            String seq = sendInVo.getKosTgSndNo();
            //String seq = bizUtil.getSeq(Sequence.TRANS);
            log.debug("seq >> " + seq);
            T6500F5 sendData = new T6500F5();
            sendData.setTG_LEN(TG_LEN);                            // 1. 전문 길이
            sendData.setTG_DSC(BNK_TG_DSC);             // 2. 전문 구분 코드
            sendData.setBNK_TG_NO(sendInVo.getBnkTgNo());           // 3. 우리 은행 전문 번호
            sendData.setFA_TG_NO(sendInVo.getFaTgNo());                        // 4. 보험사 전문 번호
            sendData.setKOS_TG_SND_NO(sendInVo.getKosTgSndNo());                        // 5. KOS 관리 번호
            sendData.setTG_SND_DTM(DateUtil.getCurrentDateTime()); // 6. 전문 전송 일시
            sendData.setRES_CD(RES_CD);                            // 7. 응답 코드
            sendData.setLN_APRV_NO(StringUtil.rpad(sendInVo.getLoanNo(), 14, "0"));
            sendData.setRSRV_ITM_H(RSRV_ITM_H);                    // 8. 예약 정보 필드
            sendData.setLND_DSC(sendInVo.getLndDsc());             // 9. 대출 구분 코드
            sendData.setLND_KND_CD(sendInVo.getLndKndCd());
            sendData.setFND_USE_CD(sendInVo.getFndUseCd());
            sendData.setBNK_LND_PRDT_CD(sendInVo.getBnkLndProdtCd());
            sendData.setBNK_LND_PRDT_NM(sendInVo.getBnkLndProdtNm());
            sendData.setSTND_APL_YN(sendInVo.getStndApnYn());
            sendData.setMV_LWYR_CNFM_YN(sendInVo.getMvLwyrCnfmYn());
            sendData.setRGSTR_UNQ_NO_1(sendInVo.getRgstrUnqNo1());
            sendData.setRGSTR_UNQ_NO_2(sendInVo.getRgstrUnqNo2());
            sendData.setRGSTR_UNQ_NO_3(sendInVo.getRgstrUnqNo3());
            sendData.setRGSTR_UNQ_NO_4(sendInVo.getRgstrUnqNo4());
            sendData.setRGSTR_UNQ_NO_5(sendInVo.getRgstrUnqNo5());
            sendData.setRLES_DSC(sendInVo.getRlesDsc());
            sendData.setTRGT_RLES_DSC(sendInVo.getTrgtRlesDsc());
            sendData.setTRGT_RLES_ADDR(sendInVo.getTrgtRlesAddr());
            sendData.setBF_ASK_DT(sendInVo.getBfAskDt());
            sendData.setLND_PLN_DT(sendInVo.getLndPlnDt());
            sendData.setSL_PRC(sendInVo.getSlPrc());
            sendData.setSCRT_EVL_AMT(sendInVo.getScrtevlAmt());
            sendData.setISRN_ENTR_AMT(sendInVo.getIsrnEntrAmt());
            sendData.setLND_AMT(sendInVo.getLndAmt().toString());
            sendData.setBNK_FXCLT_RGSTR_RNK(sendInVo.getBnkfxcltRgstrRnk().toString());
            sendData.setDBTR_NM(sendInVo.getDbtrNm());
            sendData.setDBTR_BIRTH_DT(sendInVo.getDbtrBirthDt());
            sendData.setDBTR_ADDR(sendInVo.getDbtrAddr());
            sendData.setDBTR_PHNO(sendInVo.getDbtrPhno());
            sendData.setDBTR_HPNO(sendInVo.getDbtrHpno());
            sendData.setPWPS_NM(sendInVo.getPwpsNm());
            sendData.setPWPS_BIRTH_DT(sendInVo.getPwpsBirthDt());
            sendData.setPWPS_ADDR(sendInVo.getPwpsAddr());
            sendData.setPWPS_PHNO(sendInVo.getPwpsPhno());
            sendData.setPWPS_HPNO(sendInVo.getPwpsHpno());
            sendData.setRMK_FCT(sendInVo.getRmkFct());
            sendData.setLND_HNDG_SLF_DSC(sendInVo.getLndHndgSlfDsc());
            sendData.setBNK_BRNCH_NM(sendInVo.getBnkBrnchNm());
            sendData.setBNK_DRCTR_NM(sendInVo.getBnkDrctrNm());
            sendData.setBNK_BRNCH_PHNO(sendInVo.getBnkBrnchPhno());
            sendData.setBNK_DRCTR_HP(sendInVo.getBnkDrctrHp());
            sendData.setBNK_BRNCH_FAX(sendInVo.getBnkBrnchFax());
            sendData.setBNK_BRNCH_ADDR(sendInVo.getBnkBrnchAddr());
            sendData.setSLMN_CMPY_NM(sendInVo.getSlmnCmpyNm());
            sendData.setSLMN_NM(sendInVo.getSlmnNm());
            sendData.setSLMN_PHNO(sendInVo.getSlmnPhno());
            sendData.setRFR_LN_APRV_NO(sendInVo.getRfrLnAprvNo());
            sendData.setRGSTR_MTD_DSC(sendInVo.getRgstrMtdDsc());
            sendData.setODPRT_RPY_EANE(sendInVo.getOdprtRpyEane());
            sendData.setELTN_ESTBS_LWYR_NM(sendInVo.getEltnEstbsLwyrNm());
            sendData.setELTN_ESTBS_LWYR_BIZNO(sendInVo.getEltnEstbsLwyrBizNo());
            sendData.setSL_CNTRCT_EANE(sendInVo.getSlCntrctEane());
            sendData.setSL_CNTRCT_FLNM(sendInVo.getSlCntrctFlnm());
            sendData.setAFRGSTR_SCRT_YN(sendInVo.getAfrgstrScrtYn());
            sendData.setBNK_BRNCH_CD(sendInVo.getBnkBrnchCd());
            sendData.setRSRV_ITM_B(sendInVo.getRsrvItmB());

            log.debug(sendData.toString());
            String lnAprovNo = bizUtil.getSeq(Sequence.CNTR).concat("000");
            insCmnSvc.insSend(InsCmnSvo.insCmnInVo.builder()
                    .tgSqn(seq)
                    .bnkCd(BNK_CD)
                    .tgDsc(TG_DSC)
                    .trDsc(TR_DSC)
                    .reqTgCnts(sendData.dataToString())
                    .reqTgLog(sendData.print())
                    .reqTgFnYn(REQ_TG_FN_YN)
                    .resTgFnYn(RES_TG_FN_YN)
                    .loanNo(sendInVo.getLoanNo())
                    .membNo("SYSTEM")
                    .build());
            return seq;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException("전문 전송 테이블 적재시 오류가 발생했습니다! -> " + e.getMessage());
        }
    }
}
