package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnDb6100W1Dto;
import com.bankle.common.entity.TbWoTrnDb6100W1;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnDb6100W1Mapper extends DefaultMapper<TbWoTrnDb6100W1Dto, TbWoTrnDb6100W1> {
    TbWoTrnDb6100W1Mapper INSTANCE = Mappers.getMapper(TbWoTrnDb6100W1Mapper.class);
}