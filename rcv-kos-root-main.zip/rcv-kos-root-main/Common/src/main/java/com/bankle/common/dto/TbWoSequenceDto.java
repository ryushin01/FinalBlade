package com.bankle.common.dto;

import lombok.*;

import java.io.Serializable;

/**
 * DTO for {@link com.bankle.common.entity.TbWoSequence}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoSequenceDto implements Serializable {
    TbWoSequenceIdDto id;
}