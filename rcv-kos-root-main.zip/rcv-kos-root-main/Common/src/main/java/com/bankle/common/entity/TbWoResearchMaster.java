package com.bankle.common.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_RESEARCH_MASTER")
public class TbWoResearchMaster {
    @Id
    @Size(max = 20)
    @Column(name = "LOAN_NO", nullable = false, length = 20)
    private String loanNo;

    @Column(name = "FA_BNK_FXCLT_RGSTR_RNK", precision = 20)
    private BigDecimal faBnkFxcltRgstrRnk;

    @Size(max = 10)
    @Column(name = "FA_DBTR_WDNG_PLN_YN", length = 10)
    private String faDbtrWdngPlnYn;

    @Column(name = "FA_BNK_FXCLT_BND_MAX_AMT", precision = 20)
    private BigDecimal faBnkFxcltBndMaxAmt;

    @Size(max = 100)
    @Column(name = "FA_SPUS_NM", length = 100)
    private String faSpusNm;

    @Size(max = 100)
    @Column(name = "FA_WDNG_PLN_DT", length = 100)
    private String faWdngPlnDt;

    @Size(max = 10)
    @Column(name = "FA_RRCP_CNFM_YN", length = 10)
    private String faRrcpCnfmYn;

    @Size(max = 1)
    @Column(name = "FA_BNK_FXCLT_ESTBS_FN_YN", length = 1)
    private String faBnkFxcltEstbsFnYn;

    @Size(max = 1)
    @Column(name = "FA_BNK_FXCLT_RNK_MTH_YN", length = 1)
    private String faBnkFxcltRnkMthYn;

    @Size(max = 1)
    @Column(name = "FA_BNK_FXCLT_ESTBS_NO_MTH_YN", length = 1)
    private String faBnkFxcltEstbsNoMthYn;

    @Size(max = 8)
    @Column(name = "FA_BNK_FXCLT_RGSTR_ACPT_DT", length = 8)
    private String faBnkFxcltRgstrAcptDt;

    @Size(max = 8)
    @Column(name = "FA_OWN_OWNSH_MV_RGSTR_ACPT_DT", length = 8)
    private String faOwnOwnshMvRgstrAcptDt;

    @Size(max = 4)
    @Column(name = "FA_ISRN_GB_CD", length = 4)
    private String faIsrnGbCd;

    @Size(max = 14)
    @Column(name = "FA_RGSTR_UNQ_NO_1", length = 14)
    private String faRgstrUnqNo1;

    @Size(max = 14)
    @Column(name = "FA_RGSTR_UNQ_NO_2", length = 14)
    private String faRgstrUnqNo2;

    @Size(max = 14)
    @Column(name = "FA_RGSTR_UNQ_NO_3", length = 14)
    private String faRgstrUnqNo3;

    @Size(max = 14)
    @Column(name = "FA_RGSTR_UNQ_NO_4", length = 14)
    private String faRgstrUnqNo4;

    @Size(max = 14)
    @Column(name = "FA_RGSTR_UNQ_NO_5", length = 14)
    private String faRgstrUnqNo5;

    @Size(max = 50)
    @Column(name = "FA_OWN_NM_1", length = 50)
    private String faOwnNm1;

    @Size(max = 50)
    @Column(name = "FA_OWN_NM_2", length = 50)
    private String faOwnNm2;

    @Size(max = 50)
    @Column(name = "FA_OWN_NM_3", length = 50)
    private String faOwnNm3;

    @Size(max = 13)
    @Column(name = "FA_OWN_BIRTH_DT_1", length = 13)
    private String faOwnBirthDt1;

    @Size(max = 13)
    @Column(name = "FA_OWN_BIRTH_DT_2", length = 13)
    private String faOwnBirthDt2;

    @Size(max = 13)
    @Column(name = "FA_OWN_BIRTH_DT_3", length = 13)
    private String faOwnBirthDt3;

    @Size(max = 150)
    @Column(name = "FA_RMK_B2", length = 150)
    private String faRmkB2;

    @Size(max = 100)
    @Column(name = "FA_SBMT_DOC_LST", length = 100)
    private String faSbmtDocLst;

    @Size(max = 1)
    @Column(name = "FA_DBTR_RRCP_SBMT_YN", length = 1)
    private String faDbtrRrcpSbmtYn;

    @Size(max = 1)
    @Column(name = "FA_DBTR_FRC_SBMT_YN", length = 1)
    private String faDbtrFrcSbmtYn;

    @Size(max = 1)
    @Column(name = "FA_RRCP_DBTR_SLF_RGST_YN", length = 1)
    private String faRrcpDbtrSlfRgstYn;

    @Size(max = 1)
    @Column(name = "FA_RRCP_SPUS_RGST_YN", length = 1)
    private String faRrcpSpusRgstYn;

    @Size(max = 1)
    @Column(name = "FA_FRC_SPUS_CNFM_YN", length = 1)
    private String faFrcSpusCnfmYn;

    @Size(max = 1)
    @Column(name = "FA_DBTR_TGRC_SBMT_YN", length = 1)
    private String faDbtrTgrcSbmtYn;

    @Size(max = 1)
    @Column(name = "FA_TGRC_DBTR_SLF_MVIN_YN", length = 1)
    private String faTgrcDbtrSlfMvinYn;

    @Size(max = 1)
    @Column(name = "FA_TGRC_DBTR_OTSD_SPRT_HSHLD_EANE", length = 1)
    private String faTgrcDbtrOtsdSprtHshldEane;

    @Size(max = 1)
    @Column(name = "FA_EXEDT_MV_MVIN_EANE", length = 1)
    private String faExedtMvMvinEane;

    @Size(max = 1)
    @Column(name = "FA_BNK_DBTR_TGRC_MTH_YN", length = 1)
    private String faBnkDbtrTgrcMthYn;

    @Size(max = 14)
    @Column(name = "FA_MVIN_HSHLD_RD_DTM", length = 14)
    private String faMvinHshldRdDtm;

    @Size(max = 200)
    @Column(name = "FA_MVHR_TRGT_THNG_ADDR", length = 200)
    private String faMvhrTrgtThngAddr;

    @Size(max = 100)
    @Column(name = "FA_FM_MVHRDTM", length = 100)
    private String faFmMvhrdtm;

    @Size(max = 10)
    @Column(name = "FA_MVHR_HSHLDR_RNO", length = 10)
    private String faMvhrHshldrRno;

    @Size(max = 100)
    @Column(name = "FA_PRGS_DT", length = 100)
    private String faPrgsDt;

    @Size(max = 100)
    @Column(name = "FA_MVHR_HSHLDR_NM_MVIN_DT", length = 100)
    private String faMvhrHshldrNmMvinDt;

    @Column(name = "DB_OBJT_EBNK_RGSTR_RNK", precision = 20)
    private BigDecimal dbObjtEbnkRgstrRnk;

    @Size(max = 10)
    @Column(name = "DB_WDNG_PLN_YN", length = 10)
    private String dbWdngPlnYn;

    @Size(max = 10)
    @Column(name = "DB_WDNG_PLN_DT", length = 10)
    private String dbWdngPlnDt;

    @Column(name = "DB_OBJT_EBNK_BND_MAX_AMT", precision = 20)
    private BigDecimal dbObjtEbnkBndMaxAmt;

    @Size(max = 10)
    @Column(name = "DB_RRCP_CHRG_TRGT_YN", length = 10)
    private String dbRrcpChrgTrgtYn;

    @Size(max = 10)
    @Column(name = "DB_RVSN_CNTRCT_CHRG_TRGT_YN", length = 10)
    private String dbRvsnCntrctChrgTrgtYn;

    @Column(name = "DB_MGG_FNL_ODPRT_AMT")
    private Integer dbMggFnlOdprtAmt;

    @Column(name = "DB_TROL_FNL_ODPRT_AMT")
    private Integer dbTrolFnlOdprtAmt;

    @Size(max = 10)
    @Column(name = "DB_HSHLDR_CNDDT_YN", length = 10)
    private String dbHshldrCnddtYn;

    @Size(max = 10)
    @Column(name = "DB_UNMRD_HSHLDR_25AG_LSTN_YN", length = 10)
    private String dbUnmrdHshldr25agLstnYn;

    @Size(max = 10)
    @Column(name = "DB_FND_YN", length = 10)
    private String dbFndYn;

    @Size(max = 4)
    @Column(name = "DB_GRNT_AGNC_CD", length = 4)
    private String dbGrntAgncCd;

    @Size(max = 10)
    @Column(name = "DB_FND_LES_DSC", length = 10)
    private String dbFndLesDsc;

    @Size(max = 10)
    @Column(name = "DB_BNK_LES_DSC", length = 10)
    private String dbBnkLesDsc;

    @Size(max = 100)
    @Column(name = "DB_CNDTL_CNTS", length = 100)
    private String dbCndtlCnts;

    @Size(max = 1)
    @Column(name = "DB_LND_AMT_JST_PMNT_YN", length = 1)
    private String dbLndAmtJstPmntYn;

    @Size(max = 1)
    @Column(name = "DB_RCPT_JST_CHRGYN", length = 1)
    private String dbRcptJstChrgyn;

    @Size(max = 1)
    @Column(name = "DB_RGSTRACPT_THDY_YN", length = 1)
    private String dbRgstracptThdyYn;

    @Size(max = 50)
    @Column(name = "DB_RGSTR_ERSR_ACPT_NO", length = 50)
    private String dbRgstrErsrAcptNo;

    @Size(max = 1)
    @Column(name = "DB_ODPRT_JST_YN", length = 1)
    private String dbOdprtJstYn;

    @Size(max = 1)
    @Column(name = "DB_CNDTL_EXEC_YN", length = 1)
    private String dbCndtlExecYn;

    @Size(max = 1)
    @Column(name = "DB_UNUSL_FCT_EXST_YN_1", length = 1)
    private String dbUnuslFctExstYn1;

    @Size(max = 1)
    @Column(name = "DB_UNUSL_THNG_YN", length = 1)
    private String dbUnuslThngYn;

    @Lob
    @Column(name = "DB_STND_RMK")
    private String dbStndRmk;

    @Size(max = 784)
    @Column(name = "DB_RSRV_ITM_B", length = 784)
    private String dbRsrvItmB;

    @Size(max = 1)
    @Column(name = "DB_DBTR_SLF_MVIN_YN", length = 1)
    private String dbDbtrSlfMvinYn;

    @Size(max = 1)
    @Column(name = "DB_MVIN_ADDR_OPTM_YN", length = 1)
    private String dbMvinAddrOptmYn;

    @Size(max = 1)
    @Column(name = "DB_MVIN_DT_OPTM_YN", length = 1)
    private String dbMvinDtOptmYn;

    @Size(max = 1)
    @Column(name = "DB_SPUS_MVINYN", length = 1)
    private String dbSpusMvinyn;

    @Size(max = 1)
    @Column(name = "DB_DBTR_OTSD_MVIN_OPTM_YN", length = 1)
    private String dbDbtrOtsdMvinOptmYn;

    @Size(max = 1)
    @Column(name = "DB_UNUSL_FCT_EXST_YN_2", length = 1)
    private String dbUnuslFctExstYn2;

    @Lob
    @Column(name = "DB_TTL_RMK")
    private String dbTtlRmk;

    @Lob
    @Column(name = "DB_ISRN_SCRT_NO_1")
    private String dbIsrnScrtNo1;

    @Lob
    @Column(name = "DB_ISRN_SCRT_NO_2")
    private String dbIsrnScrtNo2;

    @Lob
    @Column(name = "DB_ISRN_SCRT_NO_3")
    private String dbIsrnScrtNo3;

    @Size(max = 8)
    @Column(name = "DB_LSHDR_MVIN_DT", length = 8)
    private String dbLshdrMvinDt;

    @Size(max = 4)
    @Column(name = "DB_ISRN_GB_CD", length = 4)
    private String dbIsrnGbCd;

    @Size(max = 14)
    @Column(name = "DB_RGSTR_UNQ_NO_1", length = 14)
    private String dbRgstrUnqNo1;

    @Size(max = 14)
    @Column(name = "DB_RGSTR_UNQ_NO_2", length = 14)
    private String dbRgstrUnqNo2;

    @Size(max = 14)
    @Column(name = "DB_RGSTR_UNQ_NO_3", length = 14)
    private String dbRgstrUnqNo3;

    @Size(max = 255)
    @Column(name = "DB_RMK_B4")
    private String dbRmkB4;

    @NotNull
    @Column(name = "CRT_DTM", nullable = false)
    private LocalDateTime crtDtm;

    @Size(max = 12)
    @NotNull
    @Column(name = "CRT_MEMB_NO", nullable = false, length = 12)
    private String crtMembNo;

    @NotNull
    @Column(name = "CHG_DTM", nullable = false)
    private LocalDateTime chgDtm;

    @Size(max = 12)
    @NotNull
    @Column(name = "CHG_MEMB_NO", nullable = false, length = 12)
    private String chgMembNo;

}