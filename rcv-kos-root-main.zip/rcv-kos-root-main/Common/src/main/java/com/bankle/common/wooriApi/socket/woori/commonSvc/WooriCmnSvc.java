package com.bankle.common.wooriApi.socket.woori.commonSvc;


import com.bankle.common.dto.TbWoTrnStndMasterDto;
import com.bankle.common.entity.TbWoTrnStndMaster;
import com.bankle.common.mapper.TbWoTrnStndMasterMapper;
import com.bankle.common.repo.TbWoTrnStndMasterRepository;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class WooriCmnSvc {

    private final TbWoTrnStndMasterRepository tbWoTrnStndMasterRepository;

    private final EntityManager entityManager;

    @Transactional(rollbackFor = {Exception.class})
    public CheckResponseSvo checkResponse(String seq) throws Exception {
        log.debug("CheckResponseSvo checkResponse(String seq) > " + seq);
        String resCd = null;
        CheckResponseSvo tempMap = new CheckResponseSvo();
        Thread.sleep(1000);
        Optional<TbWoTrnStndMaster> trnEntity;

        if (seq != null) {
            int reTryCnt = 0;
            while (resCd == null) {
                trnEntity = tbWoTrnStndMasterRepository.findBySeq(seq);
                if (trnEntity.isPresent()) {
                    TbWoTrnStndMasterDto trnDto = TbWoTrnStndMasterMapper.INSTANCE.toDto(trnEntity.get());
                    resCd = trnDto.getResCode();
                    log.debug("CheckResponseSvo checkResponse(String seq) > resCd > " + resCd);
                    tempMap.setRescode(resCd);
                    if (resCd != null && "".equals(resCd.trim())) {
                        resCd = null;
                    }
                    reTryCnt++;
                    if (reTryCnt == 31) {
                        break;
                    }
                } else {
                    reTryCnt++;
                    if (reTryCnt == 31) {
                        break;
                    }
                }
                Thread.sleep(1000);

                entityManager.clear();
            }

            if (resCd == null || "null".equals(resCd) || "".equals(resCd)) {
                //if (resCd != "000") {
                tempMap.setRescode("999");
                trnEntity = tbWoTrnStndMasterRepository.findBySeq(seq);
                if (trnEntity.isPresent()) {
                    var trnDto = TbWoTrnStndMasterMapper.INSTANCE.toDto(trnEntity.get());
                    trnDto.setResCode("999");
                    tbWoTrnStndMasterRepository.save(TbWoTrnStndMasterMapper.INSTANCE.toEntity(trnDto));
                }
            }
        }
        return tempMap;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void wooriSend(WooriCmnSvo.sendVo sendVo) {
        var builder = TbWoTrnStndMasterDto.builder();
        builder.seq(sendVo.getTrSeq());
        builder.trnName(sendVo.getTrnName());
        builder.trnKnd(sendVo.getTrnKnd());
        builder.reqData(sendVo.getReqData());
        builder.reqDataLog(sendVo.getReqDataLog());
        builder.reqYn("Y");
        //builder.resData(sendVo.getReqData());
        //builder.resDataLog(sendVo.getReqDataLog());
        builder.resYn("N");
        builder.approvalNum(sendVo.getApprovalNum());
        builder.membNo("SYSTEM");
        builder.bankCode(sendVo.getBankCode());
        builder.reqDttm(LocalDateTime.now());
        builder.chgDtm(LocalDateTime.now());
        builder.chgMembNo("SYSTEM");
        builder.crtDtm(LocalDateTime.now());
        builder.crtMembNo("SYSTEM");
        builder.tgDsc(sendVo.getTgDsc());
        builder.trnsStc("0");
        builder.resendCt(sendVo.getResendCt());
        builder.grpApprovalNum(sendVo.getApprovalNum());
        TbWoTrnStndMasterDto dto = builder.build();
        tbWoTrnStndMasterRepository.save(TbWoTrnStndMasterMapper.INSTANCE.toEntity(dto));
    }

    @Transactional
    public void wooriReceive(WooriCmnSvo.receiveVo receiveVo) {
        var builder = TbWoTrnStndMasterDto.builder();
        builder.seq(receiveVo.getTrSeq());
        builder.trnName(receiveVo.getTrnName());
        builder.trnKnd(receiveVo.getTrnKnd());
        builder.reqData(receiveVo.getReqData());
        builder.reqDataLog(receiveVo.getReqDataLog());
        builder.reqYn("N");
        builder.resYn("Y");
        //builder.resCode("000");
        builder.approvalNum(receiveVo.getApprovalNum());
        builder.membNo(receiveVo.getMembNo());
        builder.reptMembNo(receiveVo.getReptMembNo());
        builder.bankCode(receiveVo.getBankCode());
        builder.bankResCode(receiveVo.getBankResCode());
        builder.gubun(receiveVo.getGubun());
        builder.reqDttm(LocalDateTime.now());
        builder.resDttm(LocalDateTime.now());
        builder.imgKey(receiveVo.getImgKey());
        builder.userAgent(receiveVo.getUserAgent());
        builder.chgDtm(LocalDateTime.now());
        builder.chgMembNo("SYSTEM");
        builder.crtDtm(LocalDateTime.now());
        builder.crtMembNo("SYSTEM");
        builder.tgDsc(receiveVo.getTgDsc());
        builder.trnsStc("0");
        builder.flPth(receiveVo.getFlPth());
        builder.resendCt(0);
        builder.grpApprovalNum(receiveVo.getApprovalNum());
        TbWoTrnStndMasterDto dto = builder.build();
        log.debug("TbWoTrnStndMasterDto dto:" + dto.toString());
        tbWoTrnStndMasterRepository.save(TbWoTrnStndMasterMapper.INSTANCE.toEntity(dto));
        entityManager.flush();
    }

    @Transactional
    public void wooriRecResponse(WooriCmnSvo.receiveVo receiveVo) {
        log.debug("wooriRecResponse START!!!" + receiveVo.toString());
        Optional<TbWoTrnStndMaster> trnEntity  = tbWoTrnStndMasterRepository.findBySeq(receiveVo.getTrSeq());
        if (trnEntity.isPresent()) {
            TbWoTrnStndMasterDto trnDto = TbWoTrnStndMasterMapper.INSTANCE.toDto(trnEntity.get());
            log.debug("wooriRecResponse trnDto >>" + trnDto.toString());
            trnDto.setChgDtm(LocalDateTime.now());
            trnDto.setResData(receiveVo.getResData());
            trnDto.setResDataLog(receiveVo.getResDataLog());
            trnDto.setResCode(receiveVo.getResCode());
            trnDto.setResDttm(LocalDateTime.now());
            if("000".equals(receiveVo.getResCode())){
                trnDto.setResYn("Y");
            }
            tbWoTrnStndMasterRepository.save(TbWoTrnStndMasterMapper.INSTANCE.toEntity(trnDto));
            entityManager.flush();
            log.debug("wooriRecResponse END!!!" + receiveVo.toString());
        }
    }

    @Transactional
    public void wooriSendResponse(WooriCmnSvo.sendVo sendVo) {

        Optional<TbWoTrnStndMaster> trnEntity  = tbWoTrnStndMasterRepository.findBySeq(sendVo.getSeq());
        if (trnEntity.isPresent()) {
            TbWoTrnStndMasterDto trnDto = TbWoTrnStndMasterMapper.INSTANCE.toDto(trnEntity.get());
            trnDto.setChgDtm(LocalDateTime.now());
            trnDto.setResData(sendVo.getResData());
            trnDto.setResDataLog(sendVo.getResDataLog());
            trnDto.setResCode(sendVo.getResCode());
            trnDto.setTrnsStc("0");
            trnDto.setResendCt(0);
            tbWoTrnStndMasterRepository.save(TbWoTrnStndMasterMapper.INSTANCE.toEntity(trnDto));
            entityManager.flush();
        }
    }
}
