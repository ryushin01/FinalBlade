/**
 * 수신부(BPR) 법무사 타행 계좌 등록 요청
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class B3X0 extends GetSetData {

	byte[] TR_LN   = new byte[4];   	//전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
	byte[] TR_CD = new byte[4];   		//전문종별코드 
	byte[] TR_TP_CD  = new byte[3];   	//거래구분코드 
	byte[] LO_NO  = new byte[13];   	//관리번호
	byte[] TR_SQ  = new byte[14];   	//식별번호
	byte[] REQ_DTTM  = new byte[14];  		//송신일자
	byte[] RES_DTTM  = new byte[14];  		//수신일자
	byte[] RES_CD  = new byte[3];  		//응답코드
	byte[] BSTR_REG_NO  = new byte[10];   	//사업자등록번호
	byte[] ACCT_NO = new byte[20];  		//법무사 당행계좌번호
	byte[] LEG_BANK_CODE_1  = new byte[3];  		//법무사 타은행코드 1
	byte[] LEG_BANK_ACCTNO_1  = new byte[20];  		//법무사등록 타은행계좌번호 1
	byte[] LEG_BANK_CODE_2  = new byte[3];  		//법무사 타은행코드 2
	byte[] LEG_BANK_ACCTNO_2  = new byte[20];  		//법무사등록 타은행계좌번호 2
	byte[] LEG_BANK_CODE_3  = new byte[3];  		//법무사 타은행코드 3
	byte[] LEG_BANK_ACCTNO_3  = new byte[20];  		//법무사등록 타은행계좌번호 3
	byte[] LEG_BANK_CODE_4  = new byte[3];  		//법무사 타은행코드 4
	byte[] LEG_BANK_ACCTNO_4  = new byte[20];  		//법무사등록 타은행계좌번호 4
	byte[] LEG_BANK_CODE_5  = new byte[3];  		//법무사 타은행코드 5
	byte[] LEG_BANK_ACCTNO_5  = new byte[20];  		//법무사등록 타은행계좌번호 5
	byte[] LEG_BANK_CODE_6  = new byte[3];  		//법무사 타은행코드 6
	byte[] LEG_BANK_ACCTNO_6  = new byte[20];  		//법무사등록 타은행계좌번호 6
	byte[] LEG_BANK_CODE_7  = new byte[3];  		//법무사 타은행코드 7
	byte[] LEG_BANK_ACCTNO_7  = new byte[20];  		//법무사등록 타은행계좌번호 7
	byte[] LEG_BANK_CODE_8  = new byte[3];  		//법무사 타은행코드 8
	byte[] LEG_BANK_ACCTNO_8  = new byte[20];  		//법무사등록 타은행계좌번호 8
	byte[] LEG_BANK_CODE_9  = new byte[3];  		//법무사 타은행코드 9
	byte[] LEG_BANK_ACCTNO_9 = new byte[20];  		//법무사등록 타은행계좌번호 9
	byte[] LEG_BANK_CODE_10  = new byte[3];  		//법무사 타은행코드 10
	byte[] LEG_BANK_ACCTNO_10  = new byte[20];  		//법무사등록 타은행계좌번호 10
	
	byte[] FILLER  = new byte[175]; 	//공란

	public B3X0(){
		
		//default 값 셋팅
		setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.BSTR_REG_NO, "");
        setData(this.ACCT_NO, "");
        setData(this.LEG_BANK_CODE_1, "");
        setData(this.LEG_BANK_ACCTNO_1, "");
        setData(this.LEG_BANK_CODE_2, "");
        setData(this.LEG_BANK_ACCTNO_2, "");
        setData(this.LEG_BANK_CODE_3, "");
        setData(this.LEG_BANK_ACCTNO_3, "");
        setData(this.LEG_BANK_CODE_4, "");
        setData(this.LEG_BANK_ACCTNO_4, "");
        setData(this.LEG_BANK_CODE_5, "");
        setData(this.LEG_BANK_ACCTNO_5, "");
        setData(this.LEG_BANK_CODE_6, "");
        setData(this.LEG_BANK_ACCTNO_6, "");
        setData(this.LEG_BANK_CODE_7, "");
        setData(this.LEG_BANK_ACCTNO_7, "");
        setData(this.LEG_BANK_CODE_8, "");
        setData(this.LEG_BANK_ACCTNO_8, "");
        setData(this.LEG_BANK_CODE_9, "");
        setData(this.LEG_BANK_ACCTNO_9, "");
        setData(this.LEG_BANK_CODE_10, "");
        setData(this.LEG_BANK_ACCTNO_10, "");
                                                                                                                                                                                              
        setData(this.FILLER, "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
    public String print() {

        StringBuffer sb = new StringBuffer();
        
        sb.append("TR_LN : "              + getData(TR_LN             ) + "\tSize : " + TR_LN.length              + "\n");
        sb.append("TR_CD : "              + getData(TR_CD             ) + "\tSize : " + TR_CD.length              + "\n");
        sb.append("TR_TP_CD : "           + getData(TR_TP_CD          ) + "\tSize : " + TR_TP_CD.length           + "\n");
        sb.append("LO_NO : "              + getData(LO_NO             ) + "\tSize : " + LO_NO.length              + "\n");
        sb.append("TR_SQ : "              + getData(TR_SQ             ) + "\tSize : " + TR_SQ.length              + "\n");
        sb.append("REQ_DTTM : "           + getData(REQ_DTTM          ) + "\tSize : " + REQ_DTTM.length           + "\n");
        sb.append("RES_DTTM : "           + getData(RES_DTTM          ) + "\tSize : " + RES_DTTM.length           + "\n");
        sb.append("RES_CD : "             + getData(RES_CD            ) + "\tSize : " + RES_CD.length             + "\n");
        sb.append("BSTR_REG_NO : "        + getData(BSTR_REG_NO       ) + "\tSize : " + BSTR_REG_NO.length        + "\n");
        sb.append("ACCT_NO : "            + getData(ACCT_NO           ) + "\tSize : " + ACCT_NO.length            + "\n");
        sb.append("LEG_BANK_CODE_1 : "    + getData(LEG_BANK_CODE_1   ) + "\tSize : " + LEG_BANK_CODE_1.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_1 : "  + getData(LEG_BANK_ACCTNO_1 ) + "\tSize : " + LEG_BANK_ACCTNO_1.length  + "\n");
        sb.append("LEG_BANK_CODE_2 : "    + getData(LEG_BANK_CODE_2   ) + "\tSize : " + LEG_BANK_CODE_2.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_2 : "  + getData(LEG_BANK_ACCTNO_2 ) + "\tSize : " + LEG_BANK_ACCTNO_2.length  + "\n");
        sb.append("LEG_BANK_CODE_3 : "    + getData(LEG_BANK_CODE_3   ) + "\tSize : " + LEG_BANK_CODE_3.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_3 : "  + getData(LEG_BANK_ACCTNO_3 ) + "\tSize : " + LEG_BANK_ACCTNO_3.length  + "\n");
        sb.append("LEG_BANK_CODE_4 : "    + getData(LEG_BANK_CODE_4   ) + "\tSize : " + LEG_BANK_CODE_4.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_4 : "  + getData(LEG_BANK_ACCTNO_4 ) + "\tSize : " + LEG_BANK_ACCTNO_4.length  + "\n");
        sb.append("LEG_BANK_CODE_5 : "    + getData(LEG_BANK_CODE_5   ) + "\tSize : " + LEG_BANK_CODE_5.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_5 : "  + getData(LEG_BANK_ACCTNO_5 ) + "\tSize : " + LEG_BANK_ACCTNO_5.length  + "\n");
        sb.append("LEG_BANK_CODE_6 : "    + getData(LEG_BANK_CODE_6   ) + "\tSize : " + LEG_BANK_CODE_6.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_6 : "  + getData(LEG_BANK_ACCTNO_6 ) + "\tSize : " + LEG_BANK_ACCTNO_6.length  + "\n");
        sb.append("LEG_BANK_CODE_7 : "    + getData(LEG_BANK_CODE_7   ) + "\tSize : " + LEG_BANK_CODE_7.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_7 : "  + getData(LEG_BANK_ACCTNO_7 ) + "\tSize : " + LEG_BANK_ACCTNO_7.length  + "\n");
        sb.append("LEG_BANK_CODE_8 : "    + getData(LEG_BANK_CODE_8   ) + "\tSize : " + LEG_BANK_CODE_8.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_8 : "  + getData(LEG_BANK_ACCTNO_8 ) + "\tSize : " + LEG_BANK_ACCTNO_8.length  + "\n");
        sb.append("LEG_BANK_CODE_9 : "    + getData(LEG_BANK_CODE_9   ) + "\tSize : " + LEG_BANK_CODE_9.length    + "\n");
        sb.append("LEG_BANK_ACCTNO_9 : "  + getData(LEG_BANK_ACCTNO_9 ) + "\tSize : " + LEG_BANK_ACCTNO_9.length  + "\n");
        sb.append("LEG_BANK_CODE_10 : "   + getData(LEG_BANK_CODE_10  ) + "\tSize : " + LEG_BANK_CODE_10.length   + "\n");
        sb.append("LEG_BANK_ACCTNO_10 : " + getData(LEG_BANK_ACCTNO_10) + "\tSize : " + LEG_BANK_ACCTNO_10.length + "\n");
        sb.append("FILLER : "             + getData(FILLER            ) + "\tSize : " + FILLER.length             + "\n");                                    
        
        // System.out.println(sb.toString());

        return sb.toString();                                                                                                                                                    
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {         
    	return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
        						+ getData(BSTR_REG_NO) + getData(ACCT_NO) + getData(LEG_BANK_CODE_1) + getData(LEG_BANK_ACCTNO_1) + getData(LEG_BANK_CODE_2) + getData(LEG_BANK_ACCTNO_2) + getData(LEG_BANK_CODE_3) + getData(LEG_BANK_ACCTNO_3)
        						 + getData(LEG_BANK_CODE_4) + getData(LEG_BANK_ACCTNO_4) + getData(LEG_BANK_CODE_5) + getData(LEG_BANK_ACCTNO_5) + getData(LEG_BANK_CODE_6) + getData(LEG_BANK_ACCTNO_6) + getData(LEG_BANK_CODE_7) + getData(LEG_BANK_ACCTNO_7)
        						 + getData(LEG_BANK_CODE_8) + getData(LEG_BANK_ACCTNO_8) + getData(LEG_BANK_CODE_9) + getData(LEG_BANK_ACCTNO_9) + getData(LEG_BANK_CODE_10) + getData(LEG_BANK_ACCTNO_10)
        						+ getData(FILLER);                                                                                                                          
    }                                                                                                                                                                       
                                                                                                                                                                            
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(BSTR_REG_NO, 0, BSTR_REG_NO.length);
            stream.read(ACCT_NO, 0, ACCT_NO.length);
            stream.read(LEG_BANK_CODE_1, 0, LEG_BANK_CODE_1.length);
            stream.read(LEG_BANK_ACCTNO_1, 0, LEG_BANK_ACCTNO_1.length);
            stream.read(LEG_BANK_CODE_2, 0, LEG_BANK_CODE_2.length);
            stream.read(LEG_BANK_ACCTNO_2, 0, LEG_BANK_ACCTNO_2.length);
            stream.read(LEG_BANK_CODE_3, 0, LEG_BANK_CODE_3.length);
            stream.read(LEG_BANK_ACCTNO_3, 0, LEG_BANK_ACCTNO_3.length);
            stream.read(LEG_BANK_CODE_4, 0, LEG_BANK_CODE_4.length);
            stream.read(LEG_BANK_ACCTNO_4, 0, LEG_BANK_ACCTNO_4.length);
            stream.read(LEG_BANK_CODE_5, 0, LEG_BANK_CODE_5.length);
            stream.read(LEG_BANK_ACCTNO_5, 0, LEG_BANK_ACCTNO_5.length);
            stream.read(LEG_BANK_CODE_6, 0, LEG_BANK_CODE_6.length);
            stream.read(LEG_BANK_ACCTNO_6, 0, LEG_BANK_ACCTNO_6.length);
            stream.read(LEG_BANK_CODE_7, 0, LEG_BANK_CODE_7.length);
            stream.read(LEG_BANK_ACCTNO_7, 0, LEG_BANK_ACCTNO_7.length);
            stream.read(LEG_BANK_CODE_8, 0, LEG_BANK_CODE_8.length);
            stream.read(LEG_BANK_ACCTNO_8, 0, LEG_BANK_ACCTNO_8.length);
            stream.read(LEG_BANK_CODE_9, 0, LEG_BANK_CODE_9.length);
            stream.read(LEG_BANK_ACCTNO_9, 0, LEG_BANK_ACCTNO_9.length);
            stream.read(LEG_BANK_CODE_10, 0, LEG_BANK_CODE_10.length);
            stream.read(LEG_BANK_ACCTNO_10, 0, LEG_BANK_ACCTNO_10.length);
            
            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------
    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * 사업자등록번호
	 * @return
	 */
	public String getBSTR_REG_NO() {
		return getData(BSTR_REG_NO);
	}
	/**
	 * 법무사 당행계좌번호
	 * @return
	 */
	public String getACCT_NO() {
		return getData(ACCT_NO);
	}
	/**
	 * 법무사 타은행코드 1
	 * @return
	 */
	public String getLEG_BANK_CODE_1() {
		return getData(LEG_BANK_CODE_1);
	}
	/**
	 * 법무사 타은행계좌번호 1
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_1() {
		return getData(LEG_BANK_ACCTNO_1);
	}
	/**
	 * 법무사 타은행코드 2
	 * @return
	 */
	public String getLEG_BANK_CODE_2() {
		return getData(LEG_BANK_CODE_2);
	}
	/**
	 * 법무사 타은행계좌번호 2
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_2() {
		return getData(LEG_BANK_ACCTNO_2);
	}
	/**
	 * 법무사 타은행코드 3
	 * @return
	 */
	public String getLEG_BANK_CODE_3() {
		return getData(LEG_BANK_CODE_3);
	}
	/**
	 * 법무사 타은행계좌번호 3
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_3() {
		return getData(LEG_BANK_ACCTNO_3);
	}
	/**
	 * 법무사 타은행코드 4
	 * @return
	 */
	public String getLEG_BANK_CODE_4() {
		return getData(LEG_BANK_CODE_4);
	}
	/**
	 * 법무사 타은행계좌번호 4
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_4() {
		return getData(LEG_BANK_ACCTNO_4);
	}
	/**
	 * 법무사 타은행코드 5
	 * @return
	 */
	public String getLEG_BANK_CODE_5() {
		return getData(LEG_BANK_CODE_5);
	}
	/**
	 * 법무사 타은행계좌번호 5
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_5() {
		return getData(LEG_BANK_ACCTNO_5);
	}
	/**
	 * 법무사 타은행코드 6
	 * @return
	 */
	public String getLEG_BANK_CODE_6() {
		return getData(LEG_BANK_CODE_6);
	}
	/**
	 * 법무사 타은행계좌번호 6
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_6() {
		return getData(LEG_BANK_ACCTNO_6);
	}
	/**
	 * 법무사 타은행코드 7
	 * @return
	 */
	public String getLEG_BANK_CODE_7() {
		return getData(LEG_BANK_CODE_7);
	}
	/**
	 * 법무사 타은행계좌번호 7
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_7() {
		return getData(LEG_BANK_ACCTNO_7);
	}
	/**
	 * 법무사 타은행코드 8
	 * @return
	 */
	public String getLEG_BANK_CODE_8() {
		return getData(LEG_BANK_CODE_8);
	}
	/**
	 * 법무사 타은행계좌번호 8
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_8() {
		return getData(LEG_BANK_ACCTNO_8);
	}
	/**
	 * 법무사 타은행코드 9
	 * @return
	 */
	public String getLEG_BANK_CODE_9() {
		return getData(LEG_BANK_CODE_9);
	}
	/**
	 * 법무사 타은행계좌번호 9
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_9() {
		return getData(LEG_BANK_ACCTNO_9);
	}
	/**
	 * 법무사 타은행코드 10
	 * @return
	 */
	public String getLEG_BANK_CODE_10() {
		return getData(LEG_BANK_CODE_10);
	}
	/**
	 * 법무사 타은행계좌번호 10
	 * @return
	 */
	public String getLEG_BANK_ACCTNO_10() {
		return getData(LEG_BANK_ACCTNO_10);
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}
	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}


	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}



	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}



	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}


	
	/**
	 * 사업자등록번호
	 * @param BSTR_REG_NO
	 */
	public void setBSTR_REG_NO(String BSTR_REG_NO) {
		setData(this.BSTR_REG_NO, BSTR_REG_NO,"S");
	}
	


	/**
	 * 법무사 당행계좌번호
	 * @param ACCT_NO
	 */
	public void setACCT_NO(String ACCT_NO) {
		setData(this.ACCT_NO, ACCT_NO,"S");
	}



	/**
	 * 법무사 타은행코드 1
	 * @param LEG_BANK_CODE_1
	 */
	public void setLEG_BANK_CODE_1(String LEG_BANK_CODE_1) {
		setData(this.LEG_BANK_CODE_1, LEG_BANK_CODE_1,"S");
	}



	/**
	 * 법무사 타은행계좌번호 1
	 * @param LEG_BANK_ACCTNO_1
	 */
	public void setLEG_BANK_ACCTNO_1(String LEG_BANK_ACCTNO_1) {
		setData(this.LEG_BANK_ACCTNO_1, LEG_BANK_ACCTNO_1,"S");
	}
	


	/**
	 * 법무사 타은행코드 2
	 * @param LEG_BANK_CODE_2
	 */
	public void setLEG_BANK_CODE_2(String LEG_BANK_CODE_2) {
		setData(this.LEG_BANK_CODE_2, LEG_BANK_CODE_2,"S");
	}



	/**
	 * 법무사 타은행계좌번호 2
	 * @param LEG_BANK_ACCTNO_2
	 */
	public void setLEG_BANK_ACCTNO_2(String LEG_BANK_ACCTNO_2) {
		setData(this.LEG_BANK_ACCTNO_2, LEG_BANK_ACCTNO_2,"S");
	}
	


	/**
	 * 법무사 타은행코드 
	 * @param LEG_BANK_CODE_3
	 */
	public void setLEG_BANK_CODE_3(String LEG_BANK_CODE_3) {
		setData(this.LEG_BANK_CODE_3, LEG_BANK_CODE_3,"S");
	}



	/**
	 * 법무사 타은행계좌번호 
	 * @param LEG_BANK_ACCTNO_
	 */
	public void setLEG_BANK_ACCTNO_3(String LEG_BANK_ACCTNO_3) {
		setData(this.LEG_BANK_ACCTNO_3, LEG_BANK_ACCTNO_3,"S");
	}
	


	/**
	 * 법무사 타은행코드 
	 * @param LEG_BANK_CODE_4
	 */
	public void setLEG_BANK_CODE_4(String LEG_BANK_CODE_4) {
		setData(this.LEG_BANK_CODE_4, LEG_BANK_CODE_4,"S");
	}



	/**
	 * 법무사 타은행계좌번호 4
	 * @param LEG_BANK_ACCTNO_4
	 */
	public void setLEG_BANK_ACCTNO_4(String LEG_BANK_ACCTNO_4) {
		setData(this.LEG_BANK_ACCTNO_4, LEG_BANK_ACCTNO_4,"S");
	}
	


	/**
	 * 법무사 타은행코드 5
	 * @param LEG_BANK_CODE_5
	 */
	public void setLEG_BANK_CODE_5(String LEG_BANK_CODE_5) {
		setData(this.LEG_BANK_CODE_5, LEG_BANK_CODE_5,"S");
	}



	/**
	 * 법무사 타은행계좌번호 5
	 * @param LEG_BANK_ACCTNO_5
	 */
	public void setLEG_BANK_ACCTNO_5(String LEG_BANK_ACCTNO_5) {
		setData(this.LEG_BANK_ACCTNO_5, LEG_BANK_ACCTNO_5,"S");
	}
	


	/**
	 * 법무사 타은행코드 6
	 * @param LEG_BANK_CODE_6
	 */
	public void setLEG_BANK_CODE_6(String LEG_BANK_CODE_6) {
		setData(this.LEG_BANK_CODE_6, LEG_BANK_CODE_6,"S");
	}



	/**
	 * 법무사 타은행계좌번호 6
	 * @param LEG_BANK_ACCTNO_6
	 */
	public void setLEG_BANK_ACCTNO_6(String LEG_BANK_ACCTNO_6) {
		setData(this.LEG_BANK_ACCTNO_6, LEG_BANK_ACCTNO_6,"S");
	}
	


	/**
	 * 법무사 타은행코드 7
	 * @param LEG_BANK_CODE_7
	 */
	public void setLEG_BANK_CODE_7(String LEG_BANK_CODE_7) {
		setData(this.LEG_BANK_CODE_7, LEG_BANK_CODE_7,"S");
	}



	/**
	 * 법무사 타은행계좌번호 7
	 * @param LEG_BANK_ACCTNO_7
	 */
	public void setLEG_BANK_ACCTNO_7(String LEG_BANK_ACCTNO_7) {
		setData(this.LEG_BANK_ACCTNO_7, LEG_BANK_ACCTNO_7,"S");
	}
	


	/**
	 * 법무사 타은행코드 8
	 * @param LEG_BANK_CODE_8
	 */
	public void setLEG_BANK_CODE_8(String LEG_BANK_CODE_8) {
		setData(this.LEG_BANK_CODE_8, LEG_BANK_CODE_8,"S");
	}



	/**
	 * 법무사 타은행계좌번호 8
	 * @param LEG_BANK_ACCTNO_8
	 */
	public void setLEG_BANK_ACCTNO_8(String LEG_BANK_ACCTNO_8) {
		setData(this.LEG_BANK_ACCTNO_8, LEG_BANK_ACCTNO_8,"S");
	}
	


	/**
	 * 법무사 타은행코드 9
	 * @param LEG_BANK_CODE_9
	 */
	public void setLEG_BANK_CODE_9(String LEG_BANK_CODE_9) {
		setData(this.LEG_BANK_CODE_9, LEG_BANK_CODE_9,"S");
	}



	/**
	 * 법무사 타은행계좌번호 9
	 * @param LEG_BANK_ACCTNO_9
	 */
	public void setLEG_BANK_ACCTNO_9(String LEG_BANK_ACCTNO_9) {
		setData(this.LEG_BANK_ACCTNO_9, LEG_BANK_ACCTNO_9,"S");
	}
	


	/**
	 * 법무사 타은행코드 10
	 * @param LEG_BANK_CODE_10
	 */
	public void setLEG_BANK_CODE_10(String LEG_BANK_CODE_10) {
		setData(this.LEG_BANK_CODE_10, LEG_BANK_CODE_10,"S");
	}



	/**
	 * 법무사 타은행계좌번호 10
	 * @param LEG_BANK_ACCTNO_10
	 */
	public void setLEG_BANK_ACCTNO_10(String LEG_BANK_ACCTNO_10) {
		setData(this.LEG_BANK_ACCTNO_10, LEG_BANK_ACCTNO_10,"S");
	}
	


	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}

}
