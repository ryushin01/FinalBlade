package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnFa6100F1Dto;
import com.bankle.common.entity.TbWoTrnFa6100F1;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnFa6100F1Mapper extends DefaultMapper<TbWoTrnFa6100F1Dto, TbWoTrnFa6100F1> {
    TbWoTrnFa6100F1Mapper INSTANCE = Mappers.getMapper(TbWoTrnFa6100F1Mapper.class);
}