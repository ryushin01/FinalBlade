package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnFa6200F2;
import com.bankle.common.entity.TbWoTrnFa6200F2Id;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TbWoTrnFa6200F2Repository extends JpaRepository<TbWoTrnFa6200F2, TbWoTrnFa6200F2Id> {
}