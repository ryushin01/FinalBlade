package com.bankle.common.vo;

import lombok.*;

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResPagingData<T> {

    private T data;
}
