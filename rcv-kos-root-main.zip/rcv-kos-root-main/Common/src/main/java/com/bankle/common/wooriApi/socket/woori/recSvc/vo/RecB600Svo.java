package com.bankle.common.wooriApi.socket.woori.recSvc.vo;

import com.bankle.common.wooriApi.socket.woori.socketData.B6X0;
import lombok.*;

public class RecB600Svo {

    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class receiveVo {

        private String trSeq;

        private String tpCd;

        private String trnKnd;

        private String trnName;

        private String reqDttm;

        private String reqDt;

        private String reqYn;

        private String resCode;

        private String reqData;

        private String reqDataLog;

        private String approvalNum;

        private String loanNo;

        private String loNo;

        private String insGbn;

        private String kindCd;

        private String bizNo;

        private String reptMembNo;

        private String membNo;

        private String tgDsc;

        private String gubun;

        private B6X0 b6X0;
    }
}
