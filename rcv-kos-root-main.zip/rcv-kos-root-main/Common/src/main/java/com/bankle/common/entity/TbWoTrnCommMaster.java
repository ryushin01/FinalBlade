package com.bankle.common.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_COMM_MASTER")
public class TbWoTrnCommMaster {
    @Id
    @Size(max = 14)
    @Column(name = "TG_SQN", nullable = false, length = 14)
    private String tgSqn;

    @Size(max = 3)
    @Column(name = "BNK_CD", length = 3)
    private String bnkCd;

    @Size(max = 5)
    @Column(name = "TG_DSC", length = 5)
    private String tgDsc;

    @Size(max = 3)
    @Column(name = "TR_DSC", length = 3)
    private String trDsc;

    @Column(name = "REQ_DTM")
    private LocalDateTime reqDtm;

    @Size(max = 4000)
    @Column(name = "REQ_TG_CNTS", length = 4000)
    private String reqTgCnts;

    @Lob
    @Column(name = "REQ_TG_LOG")
    private String reqTgLog;

    @Size(max = 1)
    @Column(name = "REQ_TG_FN_YN", length = 1)
    private String reqTgFnYn;

    @Column(name = "RES_DTM")
    private LocalDateTime resDtm;

    @Size(max = 4000)
    @Column(name = "RES_TG_CNTS", length = 4000)
    private String resTgCnts;

    @Lob
    @Column(name = "RES_TG_LOG")
    private String resTgLog;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Lob
    @Column(name = "RES_MSG")
    private String resMsg;

    @Size(max = 1)
    @Column(name = "RES_TG_FN_YN", length = 1)
    private String resTgFnYn;

    @Size(max = 14)
    @Column(name = "LN_APRV_NO", length = 14)
    private String lnAprvNo;

    @Size(max = 200)
    @Column(name = "IMG_KEY", length = 200)
    private String imgKey;

    @Size(max = 1000)
    @Column(name = "USER_AGENT", length = 1000)
    private String userAgent;

    @Column(name = "CRT_DTM")
    private LocalDateTime crtDtm;

    @Size(max = 13)
    @Column(name = "CRT_MEMB_NO", length = 13)
    private String crtMembNo;

    @Column(name = "CHG_DTM")
    private LocalDateTime chgDtm;

    @Size(max = 13)
    @Column(name = "CHG_MEMB_NO", length = 13)
    private String chgMembNo;

    @Size(max = 1)
    @Column(name = "TRNS_STC", length = 1)
    private String trnsStc;

    @ColumnDefault("0")
    @Column(name = "RESEND_CT")
    private Integer resendCt;

}