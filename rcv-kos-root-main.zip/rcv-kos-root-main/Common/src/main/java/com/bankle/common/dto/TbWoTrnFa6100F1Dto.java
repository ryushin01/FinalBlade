package com.bankle.common.dto;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnFa6100F1}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnFa6100F1Dto implements Serializable {
    TbWoTrnFa6100F1IdDto id;
    BigDecimal tgLen;
    @Size(max = 4)
    String tgDsc;
    @Size(max = 8)
    String bnkTgNo;
    @Size(max = 8)
    String faTgNo;
    @Size(max = 14)
    String kosTgSndNo;
    LocalDateTime tgSndDtm;
    LocalDateTime tgRcvDtm;
    @Size(max = 3)
    String resCd;
    @Size(max = 35)
    String rsrvItmH;
    @Size(max = 20)
    String bnkTtlReqNo;
    @Size(max = 1)
    String ttlArdEntrEane;
    @Size(max = 1)
    String ttlEntrcmpy;
    @Size(max = 15)
    String ttlScrtNo;
    @Size(max = 2)
    String lndDsc;
    @Size(max = 2)
    String lndKndCd;
    @Size(max = 2)
    String fndUseCd;
    @Size(max = 9)
    String bnkLndPrdtCd;
    @Size(max = 200)
    String bnkLndPrdtNm;
    @Size(max = 2)
    String grntDsc;
    @Size(max = 1)
    String stndAplYn;
    @Size(max = 1)
    String rrcpCnfmReqYn;
    @Size(max = 1)
    String mvhrCnfmReqYn;
    @Size(max = 1)
    String bfSrvtrgtReqYn;
    @Size(max = 1)
    String afSrvtrgtReqYn;
    @Size(max = 14)
    String rgstrUnqNo1;
    @Size(max = 14)
    String rgstrUnqNo2;
    @Size(max = 14)
    String rgstrUnqNo3;
    @Size(max = 14)
    String rgstrUnqNo4;
    @Size(max = 14)
    String rgstrUnqNo5;
    @Size(max = 1)
    String rlesDsc;
    @Size(max = 2)
    String trgtRlesDsc;
    @Size(max = 300)
    String trgtRlesAddr;
    @Size(max = 8)
    String sscptAskDt;
    @Size(max = 8)
    String lndPlnDt;
    @Size(max = 8)
    String lndExprdDt;
    @NotNull
    BigDecimal slPrc;
    @NotNull
    BigDecimal isrnEntrAmt;
    @NotNull
    BigDecimal lndPrd;
    @NotNull
    BigDecimal lndAmt;
    @NotNull
    BigDecimal bnkFxcltRgstrRnk;
    @NotNull
    BigDecimal bnkFxcltBndMaxAmt;
    @Size(max = 50)
    String dbtrNm;
    @Size(max = 13)
    String dbtrBirthDt;
    @Size(max = 300)
    String dbtrAddr;
    @Size(max = 14)
    String dbtrPhno;
    @Size(max = 14)
    String dbtrHpno;
    @Size(max = 50)
    String pwpsNm;
    @Size(max = 13)
    String pwpsBirthDt;
    @Size(max = 300)
    String pwpsAddr;
    @Size(max = 14)
    String pwpsPhno;
    @Size(max = 14)
    String pwpsHpno;
    @Size(max = 200)
    String rmkFct;
    @Size(max = 1)
    String lndHndgSlfDsc;
    @Size(max = 50)
    String bnkBrnchNm;
    @Size(max = 50)
    String bnkDrctrNm;
    @Size(max = 14)
    String bnkBrnchPhno;
    @Size(max = 14)
    String bnkDrctrHp;
    @Size(max = 14)
    String bnkBrnchFax;
    @Size(max = 100)
    String bnkBrnchAddr;
    @Size(max = 50)
    String slmnCmpyNm;
    @Size(max = 50)
    String slmnNm;
    @Size(max = 14)
    String slmnPhno;
    @Size(max = 50)
    String lwfmNm;
    @Size(max = 12)
    String lwfmBizno;
    @Size(max = 1)
    String dbtrWdngPlnYn;
    @Size(max = 1)
    String rrcpCnfmYn;
    @Size(max = 50)
    String spusNm;
    @Size(max = 8)
    String wdngPlnDt;
    @Size(max = 8)
    String rschWkDdlnReqDt;
    @NotNull
    BigDecimal isrnPrmm;
    @Size(max = 20)
    String rfrLnAprvNo;
    @Size(max = 1)
    String rgstrMtdDsc;
    @Size(max = 20)
    String rgstrReqNo;
    @Size(max = 1)
    String odprtRpyEane;
    @Size(max = 50)
    String eltnEstbsLwyrNm;
    @Size(max = 12)
    String eltnEstbsLwyrBizno;
    @Size(max = 1)
    String eltnRpyLoaAplYn;
    @Size(max = 16)
    String eltnRpyLoaSqn;
    @Size(max = 6)
    String eltnRpyLoaCtfcNo;
    @NotNull
    BigDecimal whlRpyCnt;
    @NotNull
    BigDecimal whlRpyAmt;
    @NotNull
    BigDecimal ebnkRpyTotAmt;
    @NotNull
    BigDecimal dfbnkRpyTotAmt;
    @Size(max = 2)
    String rpyTrgtRnkNo1;
    @Size(max = 8)
    String rpyTrgtAcptDt1;
    @Size(max = 6)
    String rpyTrgtAcptNo1;
    @NotNull
    BigDecimal rpyTrgtBndAmt1;
    @Size(max = 2)
    String rpyTrgtRnkNo2;
    @Size(max = 8)
    String rpyTrgtAcptDt2;
    @Size(max = 6)
    String rpyTrgtAcptNo2;
    @NotNull
    BigDecimal rpyTrgtBndAmt2;
    @Size(max = 2)
    String rpyTrgtRnkNo3;
    @Size(max = 8)
    String rpyTrgtAcptDt3;
    @Size(max = 6)
    String rpyTrgtAcptNo3;
    @NotNull
    BigDecimal rpyTrgtBndAmt3;
    @Size(max = 2)
    String rpyTrgtRnkNo4;
    @Size(max = 8)
    String rpyTrgtAcptDt4;
    @Size(max = 6)
    String rpyTrgtAcptNo4;
    @NotNull
    BigDecimal rpyTrgtBndAmt4;
    @Size(max = 2)
    String rpyTrgtRnkNo5;
    @Size(max = 8)
    String rpyTrgtAcptDt5;
    @Size(max = 6)
    String rpyTrgtAcptNo5;
    @NotNull
    BigDecimal rpyTrgtBndAmt5;
    @Size(max = 1)
    String afrgstrScrtYn;
    @Size(max = 2)
    private String slmnLndProc;
    @Column(name = "SR_MEMB_NO", length = 10)
    private String srMembNo;
    private BigDecimal trAmt;
    @Size(max = 50)
    private String sllNm1;
    @Size(max = 6)
    private String sllBrDay1;
    @Size(max = 50)
    private String sllNm2;
    @Size(max = 6)
    private String sllBrDay2;
    private BigDecimal ownLoanMaxAmt;
    private BigDecimal ownLoanPlnAmt;
    @Size(max = 50)
    private String ownLoanBnkNm1;
    @Size(max = 50)
    private String ownLoanBnkNm2;
    @Size(max = 50)
    private String ownLoanBnkNm3;
    @Size(max = 50)
    private String ownLoanBnkNm4;
    @Size(max = 50)
    private String ownLoanBnkNm5;
    @Size(max = 50)
    private String cnsgnNm;
    @Size(max = 50)
    private String trstNm;
    @Size(max = 50)
    private String bnfrNm;
    @Size(max = 50)
    private String nowLessNm;
    @Size(max = 50)
    String rsrvItmB;
    LocalDateTime regDtm;
    @Size(max = 20)
    String oblMLnAprvNo;
    Integer oblTotCnt;
    Integer oblGrpRnkNo;
    @Size(max = 20)
    String lnAprvNo2;
}