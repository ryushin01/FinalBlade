package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnCommMaster}
 */
@Getter
@Setter
@ToString
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnCommMasterDto implements Serializable {
    @Size(max = 14)
    String tgSqn;
    @Size(max = 3)
    String bnkCd;
    @Size(max = 5)
    String tgDsc;
    @Size(max = 3)
    String trDsc;
    LocalDateTime reqDtm;
    @Size(max = 4000)
    String reqTgCnts;
    String reqTgLog;
    @Size(max = 1)
    String reqTgFnYn;
    LocalDateTime resDtm;
    @Size(max = 4000)
    String resTgCnts;
    String resTgLog;
    @Size(max = 3)
    String resCd;
    String resMsg;
    @Size(max = 1)
    String resTgFnYn;
    @Size(max = 14)
    String lnAprvNo;
    @Size(max = 200)
    String imgKey;
    @Size(max = 1000)
    String userAgent;
    LocalDateTime crtDtm;
    @Size(max = 13)
    String crtMembNo;
    LocalDateTime chgDtm;
    @Size(max = 13)
    String chgMembNo;
    @Size(max = 1)
    String trnsStc;
    Integer resendCt;
}