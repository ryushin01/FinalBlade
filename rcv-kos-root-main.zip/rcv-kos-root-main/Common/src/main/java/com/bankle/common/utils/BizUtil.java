package com.bankle.common.utils;


import com.bankle.common.enums.Sequence;
import com.bankle.common.repo.TbWoSequenceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@RequiredArgsConstructor
public class BizUtil {
	
	// Seq 조회
	private final TbWoSequenceRepository tbWoSequenceRepository;
	
	/**
	 *  Sequence 가져오기
	 * @name        : WooriCmnSvc.getSeq
	 * @author      : tigerBK
	 * @param       : Sequence 구분값
	 * @return      : 20230915000001
	 **/
	public  String getSeq( Sequence seqType){
		log.debug("seqType:"+seqType.toString());
		
		return tbWoSequenceRepository.getSeq(seqType.getSeqNm() , seqType.getSeqLen());
	}
}
