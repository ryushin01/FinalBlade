package com.bankle.common.repo;

import com.bankle.common.entity.TbWoSequence;
import com.bankle.common.entity.TbWoSequenceId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

public interface TbWoSequenceRepository extends JpaRepository<TbWoSequence, TbWoSequenceId> {

    @Procedure(value = "GetSequence")
    String getSeq(@Param("sequence_name") String seqName , @Param("sequence_length") int seqLength );
}