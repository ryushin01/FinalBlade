package com.bankle.common.ctrl;

import com.bankle.common.code.svc.CommSvc;
import com.bankle.common.code.vo.CommCvo;
import com.bankle.common.code.vo.CommSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 공통코드 CRUD 테이블
 *
 * @author : sh.lee
 * @version : 1.0.0
 * @Package : com.withuslaw.common.code.ctrl
 * @name : CommCtrl.java
 * @date : 2023/09/18 18:25 PM
 **/
@Tag(name = "99.공통코드", description = "공통코드 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class CommCtrl {

    private final CommSvc commSvc;
    private final CustomeModelMapper modelMapper;

    @Operation(summary = "1.공통코드 조회", description = "공통 코드 조회 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "코드 조회 성공", content = @Content(schema = @Schema(implementation = CommCvo.SearchCommCodeResCvo.class)))
    })
    @PostMapping(value = "/comm/code/searchcommcode")
    public ResponseEntity<?> searchCommCode(@Valid @RequestBody CommCvo.SearchCommCodeReqCvo searchReqCvo) throws Exception {

        try {
            log.debug("queryDsl start");
            return ResData.SUCCESS(commSvc.fndCommCode(modelMapper.mapping(searchReqCvo, CommSvo.SearchInSvo.class)));
        } catch (Exception e) {
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "2.공통코드 생성", description = "공통 코드 생성 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "코드 생성 성공", content = @Content(schema = @Schema(implementation = Long.class)))
    })
    @PostMapping(value = "/comm/code/savecommcode")
    public ResponseEntity<?> saveCommCode(@Valid @RequestBody List<CommCvo.SaveReqCvo> reqLst) throws Exception {

        try {
            log.debug("queryDsl start");
            return ResData.SUCCESS(commSvc.crtCommCode(reqLst.stream()
                    .map(
                            (element) -> modelMapper.mapping(element, CommSvo.SaveInSvo.class)
                    )
                    .toList()));
        } catch (Exception e) {
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "3.공통코드 삭제", description = "공통 코드 삭제 서비스(실제로는 사용여부 플래그만 업데이트를 진행한다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "코드 삭제 성공", content = @Content(schema = @Schema(implementation = Long.class)))
    })
    @PostMapping(value = "/comm/code/removecommcode")
    public ResponseEntity<?> removeCommCode(@Valid @RequestBody CommCvo.RemoveReqCvo removeReqCvo) throws Exception {

        try {
            log.debug("queryDsl start");
            return switch ((int) commSvc.delCommCode(modelMapper.mapping(removeReqCvo, CommSvo.RemoveInSvo.class))) {
                case 0 -> ResData.FAIL("삭제 중 오류 발생");
                case 99 -> ResData.FAIL("삭제 할 데이터 미존재");
                default ->
                        ResData.SUCCESS(commSvc.delCommCode(modelMapper.mapping(removeReqCvo, CommSvo.RemoveInSvo.class)));
            };
        } catch (Exception e) {
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "4.공통코드 수정", description = "공통 코드 수정 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "코드 수정 성공", content = @Content(schema = @Schema(implementation = Long.class)))
    })
    @PostMapping(value = "/comm/code/modifycommcode")
    public ResponseEntity<?> modifyCommCode(@Valid @RequestBody CommCvo.ModifyReqCvo modifyReqCvo) throws Exception {
        try {
            log.debug("queryDsl start");
            return switch ((int) commSvc.edtCommCode(modelMapper.mapping(modifyReqCvo, CommSvo.ModifyInSvo.class))) {
                case 0 -> ResData.FAIL("업데이트 중 오류 발생");
                case 99 -> ResData.FAIL("업데이트 할 데이터 미존재");
                default ->
                        ResData.SUCCESS(commSvc.edtCommCode(modelMapper.mapping(modifyReqCvo, CommSvo.ModifyInSvo.class)));
            };
        } catch (Exception e) {
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "5.다중 공통코드 그룹 조회", description = "다중 공통코드 그룹 조회 API")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = CommCvo.SearchCommCodeReqCvo.class)))
    })
    @PostMapping(value = "/comm/code/searchcommcodegrplist")
    public ResponseEntity<?> searchCommCodeMultiList(@RequestBody List<String> multiGprCd) {
        try {
            return ResData.SUCCESS(commSvc.searchCommCodeMultiList(multiGprCd));
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }




}