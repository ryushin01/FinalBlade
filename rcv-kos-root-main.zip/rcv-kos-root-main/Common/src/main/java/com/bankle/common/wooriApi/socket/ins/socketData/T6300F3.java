package com.bankle.common.wooriApi.socket.ins.socketData;

import java.io.InputStream;

public class T6300F3 extends GetSetData {

    private final String DATE_FORMAT = "yyyyMMddHHmmss";

    byte[] TG_LEN = new byte[4];
    byte[] TG_DSC = new byte[4];
    byte[] BNK_TG_NO = new byte[8];
    byte[] FA_TG_NO = new byte[8];
    byte[] KOS_TG_SND_NO = new byte[14];
    byte[] TG_SND_DTM = new byte[14];
    byte[] TG_RCV_DTM = new byte[14];
    byte[] RES_CD = new byte[3];
    byte[] RSRV_ITM_H = new byte[35];
    byte[] BNK_TTL_REQ_NO = new byte[20];
    byte[] LN_APRV_NO = new byte[20];
    byte[] LND_PRGS_STC = new byte[2];
    byte[] PRGS_DT = new byte[8];
    byte[] SBMT_DOC_LST = new byte[20];
    byte[] MVHR_HSHLDR_RNO = new byte[2];
    byte[] MVHR_TRGT_THNG_ADDR = new byte[300];
    byte[] MVHR_HSHLDR_NM_MVIN_DT = new byte[300];
    byte[] MVHRDTM = new byte[14];
    byte[] RSRV_ITM_B = new byte[314];


    public T6300F3() {
        setData(this.TG_LEN, "");
        setData(this.TG_DSC, "");
        setData(this.BNK_TG_NO, "");
        setData(this.FA_TG_NO, "");
        setData(this.KOS_TG_SND_NO, "");
        setData(this.TG_SND_DTM, "");
        setData(this.TG_RCV_DTM, "");
        setData(this.RES_CD, "");
        setData(this.RSRV_ITM_H, "");
        setData(this.BNK_TTL_REQ_NO, "");
        setData(this.LN_APRV_NO, "");
        setData(this.LND_PRGS_STC, "");
        setData(this.PRGS_DT, "");
        setData(this.SBMT_DOC_LST, "");
        setData(this.MVHR_HSHLDR_RNO, "");
        setData(this.MVHR_TRGT_THNG_ADDR, "");
        setData(this.MVHR_HSHLDR_NM_MVIN_DT, "");
        setData(this.MVHRDTM, "");
        setData(this.RSRV_ITM_B, "");
    }


    public String getTG_LEN() {
        return getData(TG_LEN);
    }

    public String getTG_DSC() {
        return getData(TG_DSC);
    }

    public String getBNK_TG_NO() {
        return getData(BNK_TG_NO);
    }

    public String getFA_TG_NO() {
        return getData(FA_TG_NO);
    }


    public String getKOS_TG_SND_NO() {
        return getData(KOS_TG_SND_NO);
    }


    public String getTG_SND_DTM() {
        return getData(TG_SND_DTM);
    }


    public String getTG_RCV_DTM() {
        return getData(TG_RCV_DTM);
    }

    public String getRES_CD() {
        return getData(RES_CD);
    }


    public String getRSRV_ITM_H() {
        return getData(RSRV_ITM_H);
    }


    public String getBNK_TTL_REQ_NO() {

        return getData(BNK_TTL_REQ_NO);
    }

    public String getLN_APRV_NO() {
        return getData(LN_APRV_NO);
    }


    public String getLND_PRGS_STC() {
        return getData(LND_PRGS_STC);
    }


    public String getPRGS_DT() {
        return getData(PRGS_DT);
    }


    public String getSBMT_DOC_LST() {
        return getData(SBMT_DOC_LST);
    }


    public String getMVHR_HSHLDR_RNO() {
        return getData(MVHR_HSHLDR_RNO);
    }

    public String getMVHR_TRGT_THNG_ADDR() {
        return getData(MVHR_TRGT_THNG_ADDR);
    }

    public String getMVHR_HSHLDR_NM_MVIN_DT() {
        return getData(MVHR_HSHLDR_NM_MVIN_DT);
    }


    public String getMVHRDTM() {
        return getData(MVHRDTM);
    }

    public String getRSRV_ITM_B() {
        return getData(RSRV_ITM_B);
    }

    public void setTG_LEN(String TG_LEN) {
        setData(this.TG_LEN, TG_LEN,"N");
    }

    public void setTG_DSC(String TG_DSC) {
        setData(this.TG_DSC, TG_DSC,"S");
    }


    public void setBNK_TG_NO(String BNK_TG_NO) {
        setData(this.BNK_TG_NO, BNK_TG_NO,"N");
    }


    public void setFA_TG_NO(String FA_TG_NO) {
        setData(this.FA_TG_NO, FA_TG_NO,"N");
    }


    public void setKOS_TG_SND_NO(String KOS_TG_SND_NO) {
        setData(this.KOS_TG_SND_NO, KOS_TG_SND_NO,"N");
    }


    public void setTG_SND_DTM(String TG_SND_DTM) {
        setData(this.TG_SND_DTM, TG_SND_DTM,"S");
    }


    public void setTG_RCV_DTM(String TG_RCV_DTM) {

        setData(this.TG_RCV_DTM, TG_RCV_DTM,"S");
    }


    public void setRES_CD(String RES_CD) {

        setData(this.RES_CD, RES_CD,"S");
    }

    public void setRSRV_ITM_H(String RSRV_ITM_H) {
        setData(this.RSRV_ITM_H, RSRV_ITM_H,"S");
    }


    public void setBNK_TTL_REQ_NO(String BNK_TTL_REQ_NO) {
        setData(this.BNK_TTL_REQ_NO, BNK_TTL_REQ_NO,"S");
    }


    public void setLN_APRV_NO(String LN_APRV_NO) {
        setData(this.LN_APRV_NO, LN_APRV_NO,"S");
    }


    public void setLND_PRGS_STC(String LND_PRGS_STC) {
        setData(this.LND_PRGS_STC, LND_PRGS_STC,"S");
    }


    public void setPRGS_DT(String PRGS_DT) {
        setData(this.PRGS_DT, PRGS_DT,"S");
    }


    public void setSBMT_DOC_LST(String SBMT_DOC_LST) {
        setData(this.SBMT_DOC_LST, SBMT_DOC_LST,"S");
    }


    public void setMVHR_HSHLDR_RNO(String MVHR_HSHLDR_RNO) {
        setData(this.MVHR_HSHLDR_RNO, MVHR_HSHLDR_RNO,"N");
    }


    public void setMVHR_TRGT_THNG_ADDR(String MVHR_TRGT_THNG_ADDR) {
        setData(this.MVHR_TRGT_THNG_ADDR, MVHR_TRGT_THNG_ADDR,"K");
    }


    public void setMVHR_HSHLDR_NM_MVIN_DT(String MVHR_HSHLDR_NM_MVIN_DT) {
        setData(this.MVHR_HSHLDR_NM_MVIN_DT, MVHR_HSHLDR_NM_MVIN_DT,"K");
    }


    public void setMVHRDTM(String MVHRDTM) {
        setData(this.MVHRDTM, MVHRDTM,"S");
    }


    public void setRSRV_ITM_B(String RSRV_ITM_B) {


        setData(this.RSRV_ITM_B, RSRV_ITM_B,"S");
    }

    public String dataToString() {
        return getData(TG_LEN) + getData(TG_DSC) + getData(BNK_TG_NO) + getData(FA_TG_NO) + getData(KOS_TG_SND_NO) +
                getData(TG_SND_DTM) + getData(TG_RCV_DTM) + getData(RES_CD) + getData(RSRV_ITM_H) + getData(BNK_TTL_REQ_NO) +
                getData(LN_APRV_NO) + getData(LND_PRGS_STC) + getData(PRGS_DT) + getData(SBMT_DOC_LST) + getData(MVHR_HSHLDR_RNO) +
                getData(MVHR_TRGT_THNG_ADDR) + getData(MVHR_HSHLDR_NM_MVIN_DT) + getData(MVHRDTM) + getData(RSRV_ITM_B);
    }

    public String print(){
        StringBuffer sb = new StringBuffer();
        sb.append("TG_LEN        	 	  : " + "\tSize " + TG_LEN.length + " : " + getData(TG_LEN) + "\n");
        sb.append("TG_DSC                 : " + "\tSize " + TG_DSC.length + " : " + getData(TG_DSC) + "\n");
        sb.append("BNK_TG_NO              : " + "\tSize " + BNK_TG_NO.length + " : " + getData(BNK_TG_NO) + "\n");
        sb.append("FA_TG_NO               : " + "\tSize " + FA_TG_NO.length + " : " + getData(FA_TG_NO) + "\n");
        sb.append("KOS_TG_SND_NO          : " + "\tSize " + KOS_TG_SND_NO.length + " : " + getData(KOS_TG_SND_NO) + "\n");
        sb.append("TG_SND_DTM             : " + "\tSize " + TG_SND_DTM.length + " : " + getData(TG_SND_DTM) + "\n");
        sb.append("TG_RCV_DTM             : " + "\tSize " + TG_RCV_DTM.length + " : " + getData(TG_RCV_DTM) + "\n");
        sb.append("RES_CD                 : " + "\tSize " + RES_CD.length + " : " + getData(RES_CD) + "\n");
        sb.append("RSRV_ITM_H             : " + "\tSize " + RSRV_ITM_H.length + " : " + getData(RSRV_ITM_H) + "\n");
        sb.append("BNK_TTL_REQ_NO         : " + "\tSize " + BNK_TTL_REQ_NO.length + " : " + getData(BNK_TTL_REQ_NO) + "\n");
        sb.append("LN_APRV_NO             : " + "\tSize " + LN_APRV_NO.length + " : " + getData(LN_APRV_NO) + "\n");
        sb.append("LND_PRGS_STC           : " + "\tSize " + LND_PRGS_STC.length + " : " + getData(LND_PRGS_STC) + "\n");
        sb.append("PRGS_DT                : " + "\tSize " + PRGS_DT.length + " : " + getData(PRGS_DT) + "\n");
        sb.append("SBMT_DOC_LST           : " + "\tSize " + SBMT_DOC_LST.length + " : " + getData(SBMT_DOC_LST) + "\n");
        sb.append("MVHR_HSHLDR_RNO        : " + "\tSize " + MVHR_HSHLDR_RNO.length + " : " + getData(MVHR_HSHLDR_RNO) + "\n");
        sb.append("MVHR_TRGT_THNG_ADDR    : " + "\tSize " + MVHR_TRGT_THNG_ADDR.length + " : " + getData(MVHR_TRGT_THNG_ADDR) + "\n");
        sb.append("MVHR_HSHLDR_NM_MVIN_DT : " + "\tSize " + MVHR_HSHLDR_NM_MVIN_DT.length + " : " + getData(MVHR_HSHLDR_NM_MVIN_DT) + "\n");
        sb.append("MVHRDTM                : " + "\tSize " + MVHRDTM.length + " : " + getData(MVHRDTM) + "\n");
        sb.append("RSRV_ITM_B             : " + "\tSize " + RSRV_ITM_B.length + " : " + getData(RSRV_ITM_B) + "\n");
        return sb.toString();
    }

    public void readDataStream(InputStream stream) {
        try {
            stream.read(TG_LEN, 0, TG_LEN.length);
            stream.read(TG_DSC, 0, TG_DSC.length);
            stream.read(BNK_TG_NO, 0, BNK_TG_NO.length);
            stream.read(FA_TG_NO, 0, FA_TG_NO.length);
            stream.read(KOS_TG_SND_NO, 0, KOS_TG_SND_NO.length);
            stream.read(TG_SND_DTM, 0, TG_SND_DTM.length);
            stream.read(TG_RCV_DTM, 0, TG_RCV_DTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(RSRV_ITM_H, 0, RSRV_ITM_H.length);
            stream.read(BNK_TTL_REQ_NO, 0, BNK_TTL_REQ_NO.length);
            stream.read(LN_APRV_NO, 0, LN_APRV_NO.length);
            stream.read(LND_PRGS_STC, 0, LND_PRGS_STC.length);
            stream.read(PRGS_DT, 0, PRGS_DT.length);
            stream.read(SBMT_DOC_LST, 0, SBMT_DOC_LST.length);
            stream.read(MVHR_HSHLDR_RNO, 0, MVHR_HSHLDR_RNO.length);
            stream.read(MVHR_TRGT_THNG_ADDR, 0, MVHR_TRGT_THNG_ADDR.length);
            stream.read(MVHR_HSHLDR_NM_MVIN_DT, 0, MVHR_HSHLDR_NM_MVIN_DT.length);
            stream.read(MVHRDTM, 0, MVHRDTM.length);
            stream.read(RSRV_ITM_B, 0, RSRV_ITM_B.length);
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
    }
}
