package com.bankle.common.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_FA_6500_F5")
public class TbWoTrnFa6500F5 {
    @EmbeddedId
    private TbWoTrnFa6500F5Id id;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "TG_LEN", nullable = false, precision = 4)
    private BigDecimal tgLen;

    @Size(max = 4)
    @Column(name = "TG_DSC", length = 4)
    private String tgDsc;

    @Size(max = 8)
    @NotNull
    @Column(name = "BNK_TG_NO", nullable = false, length = 8)
    private String bnkTgNo;

    @Size(max = 8)
    @NotNull
    @Column(name = "FA_TG_NO", nullable = false, length = 8)
    private String faTgNo;

    @Size(max = 14)
    @NotNull
    @Column(name = "KOS_TG_SND_NO", nullable = false, length = 14)
    private String kosTgSndNo;

    @Column(name = "TG_SND_DTM")
    private LocalDateTime tgSndDtm;

    @Column(name = "TG_RCV_DTM")
    private LocalDateTime tgRcvDtm;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 35)
    @Column(name = "RSRV_ITM_H", length = 35)
    private String rsrvItmH;

    @Size(max = 2)
    @Column(name = "LND_DSC", length = 2)
    private String lndDsc;

    @Size(max = 2)
    @Column(name = "LND_KND_CD", length = 2)
    private String lndKndCd;

    @Size(max = 2)
    @Column(name = "FND_USE_CD", length = 2)
    private String fndUseCd;

    @Size(max = 9)
    @Column(name = "BNK_LND_PRDT_CD", length = 9)
    private String bnkLndPrdtCd;

    @Size(max = 200)
    @Column(name = "BNK_LND_PRDT_NM", length = 200)
    private String bnkLndPrdtNm;

    @Size(max = 1)
    @Column(name = "STND_APL_YN", length = 1)
    private String stndAplYn;

    @Size(max = 1)
    @Column(name = "MV_LWYR_CNFM_YN", length = 1)
    private String mvLwyrCnfmYn;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_1", length = 14)
    private String rgstrUnqNo1;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_2", length = 14)
    private String rgstrUnqNo2;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_3", length = 14)
    private String rgstrUnqNo3;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_4", length = 14)
    private String rgstrUnqNo4;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_5", length = 14)
    private String rgstrUnqNo5;

    @Size(max = 1)
    @Column(name = "RLES_DSC", length = 1)
    private String rlesDsc;

    @Size(max = 2)
    @Column(name = "TRGT_RLES_DSC", length = 2)
    private String trgtRlesDsc;

    @Size(max = 300)
    @Column(name = "TRGT_RLES_ADDR", length = 300)
    private String trgtRlesAddr;

    @Size(max = 8)
    @Column(name = "BF_ASK_DT", length = 8)
    private String bfAskDt;

    @Size(max = 8)
    @Column(name = "LND_PLN_DT", length = 8)
    private String lndPlnDt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "SL_PRC", nullable = false, precision = 15)
    private BigDecimal slPrc;

    @Size(max = 15)
    @Column(name = "SCRT_EVL_AMT", length = 15)
    private String scrtEvlAmt;

    @Size(max = 15)
    @Column(name = "ISRN_ENTR_AMT", length = 15)
    private String isrnEntrAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "LND_AMT", nullable = false, precision = 15)
    private BigDecimal lndAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "BNK_FXCLT_RGSTR_RNK", nullable = false, precision = 1)
    private BigDecimal bnkFxcltRgstrRnk;

    @Size(max = 50)
    @Column(name = "DBTR_NM", length = 50)
    private String dbtrNm;

    @Size(max = 13)
    @Column(name = "DBTR_BIRTH_DT", length = 13)
    private String dbtrBirthDt;

    @Size(max = 300)
    @Column(name = "DBTR_ADDR", length = 300)
    private String dbtrAddr;

    @Size(max = 14)
    @Column(name = "DBTR_PHNO", length = 14)
    private String dbtrPhno;

    @Size(max = 14)
    @Column(name = "DBTR_HPNO", length = 14)
    private String dbtrHpno;

    @Size(max = 50)
    @Column(name = "PWPS_NM", length = 50)
    private String pwpsNm;

    @Size(max = 13)
    @Column(name = "PWPS_BIRTH_DT", length = 13)
    private String pwpsBirthDt;

    @Size(max = 300)
    @Column(name = "PWPS_ADDR", length = 300)
    private String pwpsAddr;

    @Size(max = 14)
    @Column(name = "PWPS_PHNO", length = 14)
    private String pwpsPhno;

    @Size(max = 14)
    @Column(name = "PWPS_HPNO", length = 14)
    private String pwpsHpno;

    @Lob
    @Column(name = "RMK_FCT")
    private String rmkFct;

    @Size(max = 1)
    @Column(name = "LND_HNDG_SLF_DSC", length = 1)
    private String lndHndgSlfDsc;

    @Size(max = 50)
    @Column(name = "BNK_BRNCH_NM", length = 50)
    private String bnkBrnchNm;

    @Size(max = 50)
    @Column(name = "BNK_DRCTR_NM", length = 50)
    private String bnkDrctrNm;

    @Size(max = 14)
    @Column(name = "BNK_BRNCH_PHNO", length = 14)
    private String bnkBrnchPhno;

    @Size(max = 14)
    @Column(name = "BNK_DRCTR_HP", length = 14)
    private String bnkDrctrHp;

    @Size(max = 14)
    @Column(name = "BNK_BRNCH_FAX", length = 14)
    private String bnkBrnchFax;

    @Size(max = 100)
    @Column(name = "BNK_BRNCH_ADDR", length = 100)
    private String bnkBrnchAddr;

    @Size(max = 50)
    @Column(name = "SLMN_CMPY_NM", length = 50)
    private String slmnCmpyNm;

    @Size(max = 50)
    @Column(name = "SLMN_NM", length = 50)
    private String slmnNm;

    @Size(max = 14)
    @Column(name = "SLMN_PHNO", length = 14)
    private String slmnPhno;

    @Size(max = 20)
    @Column(name = "RFR_LN_APRV_NO", length = 20)
    private String rfrLnAprvNo;

    @Size(max = 1)
    @Column(name = "RGSTR_MTD_DSC", length = 1)
    private String rgstrMtdDsc;

    @Size(max = 1)
    @Column(name = "ODPRT_RPY_EANE", length = 1)
    private String odprtRpyEane;

    @Size(max = 50)
    @Column(name = "ELTN_ESTBS_LWYR_NM", length = 50)
    private String eltnEstbsLwyrNm;

    @Size(max = 12)
    @Column(name = "ELTN_ESTBS_LWYR_BIZNO", length = 12)
    private String eltnEstbsLwyrBizno;

    @Size(max = 1)
    @Column(name = "SL_CNTRCT_EANE", length = 1)
    private String slCntrctEane;

    @Size(max = 50)
    @Column(name = "SL_CNTRCT_FLNM", length = 50)
    private String slCntrctFlnm;

    @Size(max = 1)
    @Column(name = "AFRGSTR_SCRT_YN", length = 1)
    private String afrgstrScrtYn;

    @Size(max = 6)
    @Column(name = "BNK_BRNCH_CD", length = 6)
    private String bnkBrnchCd;

    @Lob
    @Column(name = "RSRV_ITM_B")
    private String rsrvItmB;

    @Column(name = "REG_DTM")
    private LocalDateTime regDtm;

    @Size(max = 300)
    @Column(name = "TRGT_RLES_ADDR2", length = 300)
    private String trgtRlesAddr2;

    @Size(max = 1)
    @Column(name = "ADDR_SRCH_YN", length = 1)
    private String addrSrchYn;

    @Size(max = 1)
    @Column(name = "CNVNT_LWYR_YN", length = 1)
    private String cnvntLwyrYn;

    @Size(max = 20)
    @Column(name = "LN_APRV_NO2", length = 20)
    private String lnAprvNo2;

}