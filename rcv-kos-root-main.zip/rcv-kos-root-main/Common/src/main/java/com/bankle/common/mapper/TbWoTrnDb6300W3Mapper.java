package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnDb6300W3Dto;
import com.bankle.common.entity.TbWoTrnDb6300W3;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnDb6300W3Mapper extends DefaultMapper<TbWoTrnDb6300W3Dto, TbWoTrnDb6300W3> {
    TbWoTrnDb6300W3Mapper INSTANCE = Mappers.getMapper(TbWoTrnDb6300W3Mapper.class);
}