package com.bankle.common.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_CUST_BRNCH_MNG")
public class TbCustBrnchMng {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SEQ", nullable = false)
    private Long id;

    @Size(max = 10)
    @NotNull
    @Column(name = "BIZ_NO", nullable = false, length = 10)
    private String bizNo;

    @Size(max = 20)
    @Column(name = "BRNCH_CD", length = 20)
    private String brnchCd;

    @Size(max = 500)
    @NotNull
    @Column(name = "BRNCH_NM", nullable = false, length = 500)
    private String brnchNm;

}