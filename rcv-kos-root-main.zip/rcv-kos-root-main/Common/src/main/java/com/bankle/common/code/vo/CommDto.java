package com.bankle.common.code.vo;

import lombok.Data;

@Data
public class CommDto {

    String grpCd;

    String code;

    String codeNm;

    String grpNm;

    public CommDto() {
    }

    public CommDto(String grpCd, String code, String codeNm, String grpNm) {
        this.grpCd = grpCd;
        this.code = code;
        this.codeNm = codeNm;
        this.grpNm = grpNm;
    }
}
