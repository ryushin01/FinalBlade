package com.bankle.common.dto;

import com.bankle.common.entity.TbWoTrnDb6100W1Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link TbWoTrnDb6100W1Id}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnDb6100W1IdDto implements Serializable {
    @NotNull
    @Size(max = 20)
    String loanNo;
    @NotNull
    LocalDateTime chgDtm;
}