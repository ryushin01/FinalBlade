package com.bankle.common.search;

import com.querydsl.core.types.dsl.BooleanExpression;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

import static com.bankle.common.entity.QTbCommCode.tbCommCode;

public class SrchCommCode {
    public static BooleanExpression eqGrpCd(String grpCd) {
        return StringUtils.hasText(grpCd) ? tbCommCode.grpCd.eq(grpCd) : null;
    }

    public static BooleanExpression eqCode(String code) {
        return StringUtils.hasText(code) ? tbCommCode.code.eq(code) : null;
    }

    public static BooleanExpression likeGrpCd(String grpCd) {
        return StringUtils.hasText(grpCd) ? tbCommCode.grpCd.contains(grpCd) : null;
    }

    public static BooleanExpression likeCode(String code) {
        return StringUtils.hasText(code) ? tbCommCode.code.contains(code) : null;
    }

    public static BooleanExpression likeCodeNm(String codeNm) {
        return StringUtils.hasText(codeNm) ? tbCommCode.codeNm.contains(codeNm) : null;
    }
    public static BooleanExpression containsCodeNm(String codeNm) {
        return StringUtils.hasText(codeNm) ? tbCommCode.codeNm.contains(codeNm) : null;
    }

    public static BooleanExpression likeGrpNm(String grpNm) {
        return StringUtils.hasText(grpNm) ? tbCommCode.grpNm.contains(grpNm) : null;
    }

    public static BooleanExpression likeGrpDesc(String grpDesc) {
        return StringUtils.hasText(grpDesc) ? tbCommCode.grpDesc.contains(grpDesc) : null;
    }

    public static BooleanExpression eqNum(BigDecimal num) {
        return num != null ? tbCommCode.num.eq(num) : null;
    }

    public static BooleanExpression likeEtc1(String etc1) {
        return StringUtils.hasText(etc1) ? tbCommCode.etc1.contains(etc1) : null;
    }

    public static BooleanExpression likeEtc2(String etc2) {
        return StringUtils.hasText(etc2) ? tbCommCode.etc2.contains(etc2) : null;
    }

    public static BooleanExpression likeEtc3(String etc3) {
        return StringUtils.hasText(etc3) ? tbCommCode.etc3.contains(etc3) : null;
    }

    public static BooleanExpression likeUseYn(String useYn) {
        return StringUtils.hasText(useYn) ? tbCommCode.useYn.contains(useYn) : null;
    }


}
