package com.bankle.common.wooriApi.socket.woori.socketData;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

public class CmnTrans {

    public CmnTrans() {

    }

    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class setCmnTrans {
        private String insGbn;
        private String tg_dsc;
        private String ln_aprv_no;
        private String fl_pth;
    }
}
