package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_STND_MASTER")
public class TbWoTrnStndMaster {
    @Id
    @Size(max = 14)
    @Column(name = "SEQ", nullable = false, length = 14)
    private String seq;

    @Size(max = 50)
    @NotNull
    @Column(name = "TRN_NAME", nullable = false, length = 50)
    private String trnName;

    @Size(max = 14)
    @NotNull
    @Column(name = "TRN_KND", nullable = false, length = 14)
    private String trnKnd;

    @Size(max = 3000)
    @NotNull
    @Column(name = "REQ_DATA", nullable = false, length = 3000)
    private String reqData;

    @Size(max = 4000)
    @Column(name = "REQ_DATA_LOG", length = 4000)
    private String reqDataLog;

    @Size(max = 1)
    @NotNull
    @ColumnDefault("'N'")
    @Column(name = "REQ_YN", nullable = false, length = 1)
    private String reqYn;

    @Size(max = 3000)
    @Column(name = "RES_DATA", length = 3000)
    private String resData;

    @Size(max = 4000)
    @Column(name = "RES_DATA_LOG", length = 4000)
    private String resDataLog;

    @Size(max = 1)
    @NotNull
    @ColumnDefault("'N'")
    @Column(name = "RES_YN", nullable = false, length = 1)
    private String resYn;

    @Size(max = 4)
    @Column(name = "RES_CODE", length = 4)
    private String resCode;

    @Size(max = 11)
    @Column(name = "APPROVAL_NUM", length = 11)
    private String approvalNum;

    @Size(max = 13)
    @Column(name = "MEMB_NO", length = 13)
    private String membNo;

    @Size(max = 13)
    @Column(name = "REPT_MEMB_NO", length = 13)
    private String reptMembNo;

    @Size(max = 3)
    @Column(name = "BANK_CODE", length = 3)
    private String bankCode;

    @Size(max = 4)
    @Column(name = "BANK_RES_CODE", length = 4)
    private String bankResCode;

    @Size(max = 1000)
    @Column(name = "GUBUN", length = 1000)
    private String gubun;

    @Column(name = "REQ_DTTM")
    private LocalDateTime reqDttm;

    @Column(name = "RES_DTTM")
    private LocalDateTime resDttm;

    @Size(max = 27)
    @Column(name = "IMG_KEY", length = 27)
    private String imgKey;

    @Size(max = 1000)
    @Column(name = "USER_AGENT", length = 1000)
    private String userAgent;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "CHG_DTM", nullable = false)
    private LocalDateTime chgDtm;

    @Size(max = 13)
    @NotNull
    @ColumnDefault("''")
    @Column(name = "CHG_MEMB_NO", nullable = false, length = 13)
    private String chgMembNo;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "CRT_DTM", nullable = false)
    private LocalDateTime crtDtm;

    @Size(max = 13)
    @NotNull
    @ColumnDefault("''")
    @Column(name = "CRT_MEMB_NO", nullable = false, length = 13)
    private String crtMembNo;

    @Size(max = 10)
    @Column(name = "TG_DSC", length = 10)
    private String tgDsc;

    @Size(max = 1)
    @Column(name = "TRNS_STC", length = 1)
    private String trnsStc;

    @Size(max = 500)
    @Column(name = "FL_PTH", length = 500)
    private String flPth;

    @ColumnDefault("0")
    @Column(name = "RESEND_CT")
    private Integer resendCt;

    @Size(max = 11)
    @Column(name = "GRP_APPROVAL_NUM", length = 11)
    private String grpApprovalNum;

}