/**
 * 수신부(BPR) 거래 확인 서류 전송
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class B4X0 extends GetSetData {

	byte[] TR_LN   = new byte[4];   	  //전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
	byte[] TR_CD = new byte[4];   		  //전문종별코드 
	byte[] TR_TP_CD  = new byte[3];   	  //거래구분코드 
	byte[] LO_NO  = new byte[13];   	  //관리번호
	byte[] TR_SQ  = new byte[14];   	  //식별번호
	byte[] REQ_DTTM  = new byte[14];  	  //송신일자
	byte[] RES_DTTM  = new byte[14];  	  //수신일자
	byte[] RES_CD  = new byte[3];  		  //응답코드
	byte[] APPROVAL_NUM  = new byte[11];  //여신승인신청번호
	byte[] IMG_TP = new byte[1];  		  //이미지구분(1:소유권이전서류 2:당행상환영수증 3:타행상환영수증 4:근저당설정계약서 5:등기부등본 6:잔금완납영수증 7:등기접수증 8:등기필정보)
	byte[] IMG_CHECK_YN = new byte[1];	  //이미지확인여부
	byte[] IMG_KEY  = new byte[27];  	  //이미지 키
	byte[] IMG_PAGE_CNT  = new byte[1];   //이미지 페이지 수
	byte[] SEQ_NO  = new byte[4];  		  //시퀀스번호
	byte[] IMG_FILE_NAME  = new byte[36]; //이미지 파일명
	
	byte[] FILLER  = new byte[354]; 	  //공란

	public B4X0(){
		
		//default 값 셋팅
		setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.APPROVAL_NUM, "");
        setData(this.IMG_TP, "");
        setData(this.IMG_CHECK_YN, "");
        setData(this.IMG_KEY, "");
        setDataNum(this.IMG_PAGE_CNT, "");
        setData(this.SEQ_NO, "");
        setData(this.IMG_FILE_NAME, "");
                                                                                                                                                                                              
        setData(this.FILLER, "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
    public String print() {

        StringBuffer sb = new StringBuffer();
        
        sb.append("TR_LN : "         + getData(TR_LN        ) + "\tSize : " + TR_LN.length         + "\n");
        sb.append("TR_CD : "         + getData(TR_CD        ) + "\tSize : " + TR_CD.length         + "\n");
        sb.append("TR_TP_CD : "      + getData(TR_TP_CD     ) + "\tSize : " + TR_TP_CD.length      + "\n");
        sb.append("LO_NO : "         + getData(LO_NO        ) + "\tSize : " + LO_NO.length         + "\n");
        sb.append("TR_SQ : "         + getData(TR_SQ        ) + "\tSize : " + TR_SQ.length         + "\n");
        sb.append("REQ_DTTM : "      + getData(REQ_DTTM     ) + "\tSize : " + REQ_DTTM.length      + "\n");
        sb.append("RES_DTTM : "      + getData(RES_DTTM     ) + "\tSize : " + RES_DTTM.length      + "\n");
        sb.append("RES_CD : "        + getData(RES_CD       ) + "\tSize : " + RES_CD.length        + "\n");
        sb.append("APPROVAL_NUM : "  + getData(APPROVAL_NUM ) + "\tSize : " + APPROVAL_NUM.length  + "\n");
        sb.append("IMG_TP : "        + getData(IMG_TP       ) + "\tSize : " + IMG_TP.length        + "\n");
        sb.append("IMG_CHECK_YN : "  + getData(IMG_CHECK_YN ) + "\tSize : " + IMG_CHECK_YN.length  + "\n");
        sb.append("IMG_KEY : "       + getData(IMG_KEY      ) + "\tSize : " + IMG_KEY.length       + "\n");
        sb.append("IMG_PAGE_CNT : "  + getData(IMG_PAGE_CNT ) + "\tSize : " + IMG_PAGE_CNT.length  + "\n");
        sb.append("SEQ_NO : "        + getData(SEQ_NO       ) + "\tSize : " + SEQ_NO.length        + "\n");
        sb.append("IMG_FILE_NAME : " + getData(IMG_FILE_NAME) + "\tSize : " + IMG_FILE_NAME.length + "\n");
        sb.append("FILLER : "        + getData(FILLER       ) + "\tSize : " + FILLER.length        + "\n");                                                                       

        // System.out.println(sb.toString());

        return sb.toString();
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {         
    	return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
        						+ getData(APPROVAL_NUM) + getData(IMG_TP) + getData(IMG_CHECK_YN) + getData(IMG_KEY) + getData(IMG_PAGE_CNT) + getData(SEQ_NO) + getData(IMG_FILE_NAME)                                
        						+ getData(FILLER);                                                                                                                          
    }                                                                                                                                                                       
                                                                                                                                                                            
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(APPROVAL_NUM, 0, APPROVAL_NUM.length);
            stream.read(IMG_TP, 0, IMG_TP.length);
            stream.read(IMG_CHECK_YN, 0, IMG_CHECK_YN.length);
            stream.read(IMG_KEY, 0, IMG_KEY.length);
            stream.read(IMG_PAGE_CNT, 0, IMG_PAGE_CNT.length);
            stream.read(SEQ_NO, 0, SEQ_NO.length);
            stream.read(IMG_FILE_NAME, 0, IMG_FILE_NAME.length);
            
            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * 여신승인신청번호
	 * @return
	 */
	public String getAPPROVAL_NUM() {
		return getData(APPROVAL_NUM);
	}
	/**
	 * 이미지구분
	 * @return
	 */
	public String getIMG_TP() {
		return getData(IMG_TP);
	}
	/**
	 * 이미지 확인여부
	 * @return
	 */
	public String getIMG_CHECK_YN() {
		return getData(IMG_CHECK_YN);
	}
	/**
	 * 이미지 키
	 * @return
	 */
	public String getIMG_KEY() {
		return getData(IMG_KEY);
	}
	/**
	 * 이미지 페이지 수
	 * @return
	 */
	public String getIMG_PAGE_CNT() {
		return getData(IMG_PAGE_CNT);
	}
	/**
	 * 시퀀스번호
	 * @return
	 */
	public String getSEQ_NO() {
		return getData(SEQ_NO);
	}
	/**
	 * 이미지 파일명
	 * @return
	 */
	public String getIMG_FILE_NAME() {
		return getData(IMG_FILE_NAME);
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}
	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}



	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}


	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}



	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}


	
	/**
	 * 여신승인신청번호
	 * @param APPROVAL_NUM
	 */
	public void setAPPROVAL_NUM(String APPROVAL_NUM) {
		setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
	}
	


	/**
	 * 이미지구분
	 * @param IMG_TP
	 */
	public void setIMG_TP(String IMG_TP) {
		setData(this.IMG_TP, IMG_TP,"S");
	}



	/**
	 * 이미지 확인여부
	 * @param IMG_CHECK_YN
	 */
	public void setIMG_CHECK_YN(String IMG_CHECK_YN) {
		setData(this.IMG_CHECK_YN, IMG_CHECK_YN,"S");
	}
	


	/**
	 * 이미지 키
	 * @param IMG_KEY
	 */
	public void setIMG_KEY(String IMG_KEY) {
		setData(this.IMG_KEY, IMG_KEY,"S");
	}



	/**
	 * 이미지 페이지 수
	 * @param IMG_PAGE_CNT
	 */
	public void setIMG_PAGE_CNT(String IMG_PAGE_CNT) {
		setData(this.IMG_PAGE_CNT, IMG_PAGE_CNT,"N");
	}
	


	/**
	 * 시퀀스번호
	 * @param SEQ_NO
	 */
	public void setSEQ_NO(String SEQ_NO) {
		setData(this.SEQ_NO, SEQ_NO,"S");
	}
	


	/**
	 * 이미지 파일명
	 * @param IMG_FILE_NAME
	 */
	public void setIMG_FILE_NAME(String IMG_FILE_NAME) {
		setData(this.IMG_FILE_NAME, IMG_FILE_NAME,"K");
	}
	


	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}

}
