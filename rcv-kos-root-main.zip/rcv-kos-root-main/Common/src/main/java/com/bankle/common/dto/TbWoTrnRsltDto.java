package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnRslt}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnRsltDto implements Serializable {
    TbWoTrnRsltIdDto id;
    @Size(max = 3)
    String resCd;
}