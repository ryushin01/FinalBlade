package com.bankle.common.code.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

public class CommVo {

    private CommVo() {
    }

    @Getter
    @Setter
    public static class SearchCommReq {
        @Schema(example = "그룹코드")
        @Size(max = 10)
        String grpCd;

        @Schema(example = "코드")
        @Size(max = 10)
        String code;

        @Schema(example = "코드명")
        @Size(max = 100)
        String codeNm;

        @Schema(example = "그룹명")
        @Size(max = 100)
        String grpNm;

        @Schema(example = "그룹상세내용")
        @Size(max = 500)
        String grpDesc;

        @Schema(example = "순번(그룹코드에 대한 정렬순서)")
        BigDecimal num;

        @Schema(example = "비고 1")
        @Size(max = 1000)
        String etc1;

        @Schema(example = "비고 2")
        @Size(max = 1000)
        String etc2;

        @Schema(example = "비고 3")
        @Size(max = 1000)
        String etc3;

        @Schema(example = "사용여부(Y/N)")
        @Size(max = 1)
        String useYn;
    }

    @Getter
    @Setter
    public static class GetCommReq {
        @Schema(example = "11")
        @JsonProperty("code")
        String code;
        @Schema(example = "CNTR_STAT")
        @JsonProperty("grpCd")
        String grpCd;
    }

    @Getter
    @Setter
    public static class SaveCommReq {
        @Schema(example = "그룹코드")
        @Size(max = 10)
        String grpCd;

        @Schema(example = "코드")
        @Size(max = 10)
        String code;

        @Schema(example = "코드명")
        @Size(max = 100)
        String codeNm;

        @Schema(example = "그룹명")
        @Size(max = 100)
        String grpNm;

        @Schema(example = "그룹상세내용")
        @Size(max = 500)
        String grpDesc;

        @Schema(example = "순번(그룹코드에 대한 정렬순서)")
        BigDecimal num;

        @Schema(example = "비고 1")
        @Size(max = 1000)
        String etc1;

        @Schema(example = "비고 2")
        @Size(max = 1000)
        String etc2;

        @Schema(example = "비고 3")
        @Size(max = 1000)
        String etc3;

        @Schema(example = "사용여부 작성",defaultValue = "Y")
        @Size(max = 1)
        String useYn;
    }

    @Getter
    @Setter
    public static class ModifyCommReq {
        @Schema(example = "그룹코드")
        @Size(max = 10)
        String grpCd;

        @Schema(example = "코드")
        @Size(max = 10)
        String code;

        @Schema(example = "코드명")
        @Size(max = 100)
        String modifyCodeNm;

        @Schema(example = "그룹명")
        @Size(max = 100)
        String modifyGrpNm;

        @Schema(example = "그룹상세내용")
        @Size(max = 500)
        String modifyGrpDesc;

        @Schema(example = "비고 1")
        @Size(max = 1000)
        String modifyEtc1;

        @Schema(example = "비고 2")
        @Size(max = 1000)
        String modifyEtc2;

        @Schema(example = "비고 3")
        @Size(max = 1000)
        String modifyEtc3;

        @Schema(example = "Y")
        @Size(max = 1)
        String modifyUseYn;

        @Schema(hidden = true) String codeNm;
        @Schema(hidden = true) String grpNm;
        @Schema(hidden = true) String grpDesc;
        @Schema(hidden = true) String etc1;
        @Schema(hidden = true) String etc2;
        @Schema(hidden = true) String etc3;
        @Schema(hidden = true) String useYn;
    }

    @Getter
    @Setter
    public static class RemoveCommReq {
        @Schema(example = "test")
        @Size(max = 10)
        String grpCd;

        @Schema(example = "test")
        @Size(max = 10)
        String code;

        @Schema(example = "Y")
        @Size(max = 1)
        String modifyUseYn;

        @Schema(hidden = true) String codeNm;
        @Schema(hidden = true) String grpNm;
        @Schema(hidden = true) String grpDesc;
        @Schema(hidden = true) String etc1;
        @Schema(hidden = true) String etc2;
        @Schema(hidden = true) String etc3;
        @Schema(hidden = true) String useYn;
    }
}
