/**
 * 여신부 상환 신청 지금 결과 통지
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class A8X0 extends GetSetData {

	byte[] TR_LN   = new byte[4];   	 //전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
	byte[] TR_CD = new byte[4];   		 //전문종별코드 
	byte[] TR_TP_CD  = new byte[3];   	 //거래구분코드 
	byte[] LO_NO  = new byte[13];   	 //관리번호
	byte[] TR_SQ  = new byte[14];   	 //식별번호
	byte[] REQ_DTTM  = new byte[14];  	 //송신일자
	byte[] RES_DTTM  = new byte[14];  	 //수신일자
	byte[] RES_CD  = new byte[3];  		 //응답코드
	byte[] APPROVAL_NUM  = new byte[11]; //여신승인신청번호
	byte[] COMP_NAME  = new byte[50];    // 등기업체명
	byte[] POS_NAME  = new byte[10];     // 직함
	byte[] MNG_NAME  = new byte[30];     // 이름
	byte[] TEL_NO  = new byte[15];       // 전화번호
	byte[] HP_NO  = new byte[15];        // 휴대폰번호
	byte[] OFFICE_LOCAT = new byte[200]; // 사무실소재지
	byte[] PROC_DVSN  = new byte[1];     // 업무구분
	byte[] FILLER  = new byte[103]; 	 //공란

	public A8X0(){
		
		//default 값 셋팅
		setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.APPROVAL_NUM, "");
        setData(this.COMP_NAME, "");
        setData(this.POS_NAME, "");
        setData(this.MNG_NAME, "");
        setData(this.TEL_NO, "");
        setData(this.HP_NO, "");
        setData(this.OFFICE_LOCAT, "");
        setData(this.PROC_DVSN, "");
                                                                                                                                                                                              
        setData(this.FILLER, "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
	public String print() {
	    
	    StringBuffer sb = new StringBuffer();
	    
	    String comp_name    = "";
	    String mng_name     = "";
	    String office_locat = "";
	    String pos_name     = "";
	    
	    try {
	    	 comp_name    = new String(COMP_NAME   , "MS949");		    
		     mng_name     = new String(MNG_NAME    , "MS949");
		     office_locat = new String(OFFICE_LOCAT, "MS949");
		     pos_name     = new String(POS_NAME    , "MS949");                                                          
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
        	    
        sb.append("TR_CD : "           + getData(TR_CD          ) + "\tSize : " + TR_CD.length           + "\n");
        sb.append("TR_TP_CD : "        + getData(TR_TP_CD       ) + "\tSize : " + TR_TP_CD.length        + "\n");
        sb.append("LO_NO : "           + getData(LO_NO          ) + "\tSize : " + LO_NO.length           + "\n");
        sb.append("TR_SQ : "           + getData(TR_SQ          ) + "\tSize : " + TR_SQ.length           + "\n");
        sb.append("REQ_DTTM : "        + getData(REQ_DTTM       ) + "\tSize : " + REQ_DTTM.length        + "\n");
        sb.append("RES_DTTM : "        + getData(RES_DTTM       ) + "\tSize : " + RES_DTTM.length        + "\n");
        sb.append("RES_CD : "          + getData(RES_CD         ) + "\tSize : " + RES_CD.length          + "\n");
        sb.append("APPROVAL_NUM : "    + getData(APPROVAL_NUM   ) + "\tSize : " + APPROVAL_NUM.length    + "\n");
        sb.append("COMP_NAME : "       + comp_name  			  + "\tSize : " + COMP_NAME.length       + "\n");
        sb.append("POS_NAME : "        + pos_name 				  + "\tSize : " + POS_NAME.length        + "\n");
        sb.append("MNG_NAME : "        + mng_name 				  + "\tSize : " + MNG_NAME.length        + "\n");
        sb.append("TEL_NO : "          + getData(TEL_NO         ) + "\tSize : " + TEL_NO.length          + "\n");
        sb.append("HP_NO : "           + getData(HP_NO          ) + "\tSize : " + HP_NO.length           + "\n");
        sb.append("OFFICE_LOCAT : "    + office_locat             + "\tSize : " + OFFICE_LOCAT.length    + "\n");
        sb.append("PROC_DVSN : "       + getData(PROC_DVSN      ) + "\tSize : " + PROC_DVSN.length       + "\n");
        sb.append("FILLER : "          + getData(FILLER         ) + "\tSize : " + FILLER.length          + "\n");                       
                
        return sb.toString();
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {                            
        String comp_name    = "";
        String mng_name     = "";
        String office_locat = "";
        String pos_name     = "";
        
        try {
            comp_name    = new String(COMP_NAME   , "MS949");
            mng_name     = new String(MNG_NAME    , "MS949");
            office_locat = new String(OFFICE_LOCAT, "MS949");
            pos_name     = new String(POS_NAME    , "MS949");
                        
        } catch (Exception Ex) { Ex.printStackTrace(); }
        
        
        String rtnValue = getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD) 
                              + getData(APPROVAL_NUM) + comp_name + pos_name + mng_name + getData(TEL_NO) + getData(HP_NO) + office_locat
                              + getData(PROC_DVSN)
                              + getData(FILLER);
        return rtnValue;
    }                                                                                                                                                                       
                                                                                                                                                                            
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN,        0, TR_LN.length);
            stream.read(TR_CD,        0, TR_CD.length);
            stream.read(TR_TP_CD,     0, TR_TP_CD.length);
            stream.read(LO_NO,        0, LO_NO.length);
            stream.read(TR_SQ,        0, TR_SQ.length);
            stream.read(REQ_DTTM,     0, REQ_DTTM.length);
            stream.read(RES_DTTM,     0, RES_DTTM.length);
            stream.read(RES_CD,       0, RES_CD.length);
            stream.read(APPROVAL_NUM, 0, APPROVAL_NUM.length);
            stream.read(COMP_NAME,    0, COMP_NAME.length);
            stream.read(POS_NAME,     0, POS_NAME.length);
            stream.read(MNG_NAME,     0, MNG_NAME.length);
            stream.read(TEL_NO,       0, TEL_NO.length);
            stream.read(HP_NO,        0, HP_NO.length);
            stream.read(OFFICE_LOCAT, 0, OFFICE_LOCAT.length);
            stream.read(PROC_DVSN,    0, PROC_DVSN.length);
            
            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * 여신승인신청번호
	 * @return
	 */
	public String getAPPROVAL_NUM() {
		return getData(APPROVAL_NUM);
	}
	/**
	 * 등기업체명
	 * @return
	 */
	public String getCOMP_NAME() {
		return getData(COMP_NAME);
	}
	/**
	 * 직함
	 * @return
	 */
	public String getPOS_NAME() {
		return getData(POS_NAME);
	}
	/**
	 * 이름
	 * @return
	 */
	public String getMNG_NAME() {
		return getData(MNG_NAME);
	}
	/**
	 * 전화번호
	 * @return
	 */
	public String getTEL_NO() {
		return getData(TEL_NO);
	}
	/**
	 * 휴대폰번호
	 * @return
	 */
	public String getHP_NO() {
		return getData(HP_NO);
	}
	/**
	 * 사무실소재지
	 * @return
	 */
	public String getOFFICE_LOCAT() {
		return getData(OFFICE_LOCAT);
	}
	/**
	 * 업무구분
	 * @return
	 */
	public String getPROC_DVSN() {
		return getData(PROC_DVSN);
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}
	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}



	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}



	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}
	


	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}



	/**
	 * 여신승인신청번호
	 * @param APPROVAL_NUM
	 */
	public void setAPPROVAL_NUM(String APPROVAL_NUM) {
		setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
	}



	/**
	 * 등기업체명
	 * @param COMP_NAME
	 */
	public void setCOMP_NAME(String COMP_NAME) {
		setData(this.COMP_NAME, COMP_NAME,"K");
	}



	/**
	 * 직함
	 * @param POS_NAME
	 */
	public void setPOS_NAME(String POS_NAME) {
		setData(this.POS_NAME, POS_NAME,"K");
	}



	/**
	 * 이름
	 * @param POS_NAME
	 */
	public void setMNG_NAME(String MNG_NAME) {
		setData(this.MNG_NAME, MNG_NAME,"K");
	}



	/**
	 * 전화번호
	 * @param TEL_NO
	 */
	public void setTEL_NO(String TEL_NO) {
		setData(this.TEL_NO, TEL_NO,"S");
	}



	/**
	 * 휴대폰번호
	 * @param HP_NO
	 */
	public void setHP_NO(String HP_NO) {
		setData(this.HP_NO, HP_NO,"S");
	}



	/**
	 * 사무실소재지
	 * @param HP_NO
	 */
	public void setOFFICE_LOCAT(String OFFICE_LOCAT) {
		setData(this.OFFICE_LOCAT, OFFICE_LOCAT,"K");
	}

	


	/**
	 * 업무구분
	 * @param HP_NO
	 */
	public void setPROC_DVSN(String PROC_DVSN) {
		setData(this.PROC_DVSN, PROC_DVSN,"S");
	}



	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}

}

