package com.bankle.common.code.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class CommSvo {

    /**
     * 조회 요청 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SearchInSvo {

        /**
         * 그룹코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
        @Size(max = 10)
        @Schema(description = "코드", example = "10")
        String code;
        /**
         * 코드명
         */
        @Size(max = 100)
        @Schema(description = "코드명", example = "사전 견적서 발송")
        String codeNm;
        /**
         * 그룹명
         */
        @Size(max = 100)
        @Schema(description = "그룹명", example = "견적서 상태 코드")
        String grpNm;
        /**
         * 그룹설명
         */
        @Size(max = 500)
        @Schema(description = "그룹 설명", example = "견적서의 상태코드를 보여준다.")
        String grpDesc;
        /**
         * 순번(정렬순서)
         */
        @Size(max = 11)
        @Schema(description = "순번(정렬순서)", example = "2")
        BigDecimal num;
        /**
         * 기타코드1
         */
        @Size(max = 1000)
        @Schema(description = "기타코드1", example = "example")
        String etc1;
        /**
         * 기타코드2
         */
        @Size(max = 1000)
        @Schema(description = "기타코드2", example = "example")
        String etc2;
        /**
         * 기타코드3
         */
        @Size(max = 1000)
        @Schema(description = "기타코드3", example = "example")
        String etc3;
        /**
         * 사용여부
         */
        @Size(max = 1)
        @Schema(description = "사용여부", example = "Y")
        String useYn;
    }

    /**
     * 조회 응답 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Getter
    @Setter
    public static class SearchOutVo {
        /**
         * 그룹코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "코드", example = "10")
        String code;
        /**
         * 코드명
         */
        @Size(max = 100)
        @Schema(description = "코드명", example = "사전 견적서 발송")
        String codeNm;
        /**
         * 그룹명
         */
        @Size(max = 100)
        @Schema(description = "그룹명", example = "견적서 상태 코드")
        String grpNm;
        /**
         * 그룹설명
         */
        @Size(max = 500)
        @Schema(description = "그룹 설명", example = "견적서의 상태코드를 보여준다.")
        String grpDesc;
        /**
         * 순번(정렬순서)
         */
        @Size(max = 11)
        @Schema(description = "순번(정렬순서)", example = "2")
        BigDecimal num;
        /**
         * 기타코드1
         */
        @Size(max = 1000)
        @Schema(description = "기타코드1", example = "example")
        String etc1;
        /**
         * 기타코드2
         */
        @Size(max = 1000)
        @Schema(description = "기타코드2", example = "example")
        String etc2;
        /**
         * 기타코드3
         */
        @Size(max = 1000)
        @Schema(description = "기타코드3", example = "example")
        String etc3;
        /**
         * 사용여부
         */
        @Size(max = 1)
        @Schema(description = "사용여부", example = "Y")
        String useYn;
        /**
         * 생성일시
         */
        @Schema(description = "생성일시", example = "2023-10-23 17:35:00.000")
        LocalDateTime crtDtm;
        /**
         * 생성회원번호
         */
        @Size(max = 12)
        @Schema(description = "생성회원번호", example = "SYSTEM")
        String crtMembNo;
        /**
         * 수정일시
         */
        @Schema(description = "수정일시", example = "2023-10-23 17:35:00.000")
        LocalDateTime chgDtm;
        /**
         * 수정회원번호
         */
        @Size(max = 12)
        @Schema(description = "수정회원번호", example = "SYSTEM")
        String chgMembNo;
    }

    /**
     * 저장 요청 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Getter
    @Setter
    public static class SaveInSvo {
        /**
         * 그룹코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "코드", example = "10")
        String code;
        /**
         * 코드명
         */
        @Size(max = 100)
        @Schema(description = "코드명", example = "사전 견적서 발송")
        String codeNm;
        /**
         * 그룹명
         */
        @Size(max = 100)
        @Schema(description = "그룹명", example = "견적서 상태 코드")
        String grpNm;
        /**
         * 그룹설명
         */
        @Size(max = 500)
        @Schema(description = "그룹 설명", example = "견적서의 상태코드를 보여준다.")
        String grpDesc;
        /**
         * 순번(정렬순서)
         */
        @Size(max = 11)
        @Schema(description = "순번(정렬순서)", example = "2")
        BigDecimal num;
        /**
         * 기타코드1
         */
        @Size(max = 1000)
        @Schema(description = "기타코드1", example = "example")
        String etc1;
        /**
         * 기타코드2
         */
        @Size(max = 1000)
        @Schema(description = "기타코드2", example = "example")
        String etc2;
        /**
         * 기타코드3
         */
        @Size(max = 1000)
        @Schema(description = "기타코드3", example = "example")
        String etc3;
        /**
         * 사용여부
         */
        @Size(max = 1)
        @Schema(description = "사용여부", example = "Y")
        String useYn;
    }

    /**
     * 수정 요청 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Getter
    @Setter
    public static class ModifyInSvo {
        /**
         * 그룹코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "코드", example = "10")
        String code;
        /**
         * 코드명
         */
        @Size(max = 100)
        @Schema(description = "코드명", example = "사전 견적서 발송")
        String modifyCodeNm;
        /**
         * 그룹명
         */
        @Size(max = 100)
        @Schema(description = "그룹명", example = "견적서 상태 코드")
        String modifyGrpNm;
        /**
         * 그룹설명
         */
        @Size(max = 500)
        @Schema(description = "그룹 설명", example = "견적서의 상태코드를 보여준다.")
        String modifyGrpDesc;
        /**
         * 기타코드1
         */
        @Size(max = 1000)
        @Schema(description = "기타코드1", example = "example")
        String modifyEtc1;
        /**
         * 기타코드2
         */
        @Size(max = 1000)
        @Schema(description = "기타코드2", example = "example")
        String modifyEtc2;
        /**
         * 기타코드3
         */
        @Size(max = 1000)
        @Schema(description = "기타코드3", example = "example")
        String modifyEtc3;
        /**
         * 사용여부
         */
        @Size(max = 1)
        @Schema(description = "사용여부", example = "Y")
        String modifyUseYn;
        @Schema(hidden = true)
        String codeNm;
        @Schema(hidden = true)
        String grpNm;
        @Schema(hidden = true)
        String grpDesc;
        @Schema(hidden = true)
        String etc1;
        @Schema(hidden = true)
        String etc2;
        @Schema(hidden = true)
        String etc3;
        @Schema(hidden = true)
        String useYn;
    }

    /**
     * 삭제 요청 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Getter
    @Setter
    public static class RemoveInSvo {
        /**
         * 그룹코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "코드", example = "10")
        String code;
        /**
         * 코드명
         */
        @Size(max = 100)
        @Schema(description = "코드명", example = "사전 견적서 발송")
        String codeNm;
        /**
         * 그룹명
         */
        @Size(max = 100)
        @Schema(description = "그룹명", example = "견적서 상태 코드")
        String grpNm;
        /**
         * 그룹설명
         */
        @Size(max = 500)
        @Schema(description = "그룹 설명", example = "견적서의 상태코드를 보여준다.")
        String grpDesc;
        /**
         * 기타코드1
         */
        @Size(max = 1000)
        @Schema(description = "기타코드1", example = "example")
        String etc1;
        /**
         * 기타코드2
         */
        @Size(max = 1000)
        @Schema(description = "기타코드2", example = "example")
        String etc2;
        /**
         * 기타코드3
         */
        @Size(max = 1000)
        @Schema(description = "기타코드3", example = "example")
        String etc3;
        /**
         * 사용여부
         */
        @Size(max = 1)
        @Schema(description = "사용여부", example = "Y")
        String useYn;
    }

    /**
     * 단건 조회 요청 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Getter
    @Setter
    public static class GetInSvo {
        /**
         * 그룹코드
         */
//        @NotEmpty
//        @Size(max = 10)
//        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
//        @NotEmpty
//        @Size(max = 10)
//        @Schema(description = "코드", example = "10")
        String code;
    }

    /**
     * 단건 조회 응답 {@link com.bankle.common.code.svc.CommSvc}
     */
    @Data
    public static class GetOutSvo {
        /**
         * 그룹코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "그룹코드", example = "ESTM_STAT")
        String grpCd;
        /**
         * 코드
         */
        @NotEmpty
        @Size(max = 10)
        @Schema(description = "코드", example = "10")
        String code;
        /**
         * 코드명
         */
        @Size(max = 100)
        @Schema(description = "코드명", example = "사전 견적서 발송")
        String codeNm;
        /**
         * 그룹명
         */
        @Size(max = 100)
        @Schema(description = "그룹명", example = "견적서 상태 코드")
        String grpNm;

        public GetOutSvo() {
        }

        public GetOutSvo(String grpCd, String code, String codeNm, String grpNm) {
            this.grpCd = grpCd;
            this.code = code;
            this.codeNm = codeNm;
            this.grpNm = grpNm;
        }
    }


    @Getter
    @Setter
    public static class CommOutReptSvo {
        private String reptMembNo;
    }
}
