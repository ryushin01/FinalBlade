package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_CNTR_PAYMENT_LIST")
public class TbWoCntrPaymentList {
    @EmbeddedId
    private TbWoCntrPaymentListId id;

    @Size(max = 2)
    @Column(name = "PAY_CD", length = 2)
    private String payCd;

    @Size(max = 2)
    @Column(name = "STAT_CD", length = 2)
    private String statCd;

    @Size(max = 3)
    @Column(name = "BANK_CD", length = 3)
    private String bankCd;

    @Column(name = "PAY_AMT", precision = 50)
    private BigDecimal payAmt;

    @Size(max = 8)
    @Column(name = "PAY_REQ_DT", length = 8)
    private String payReqDt;

    @Size(max = 8)
    @Column(name = "PAY_CMPL_DT", length = 8)
    private String payCmplDt;

    @Column(name = "RCPT_REG_DTM")
    private LocalDateTime rcptRegDtm;

    @Column(name = "RCPT_BNK_TRANS_DTM")
    private LocalDateTime rcptBnkTransDtm;

    @Size(max = 200)
    @Column(name = "GPS_INFO", length = 200)
    private String gpsInfo;

    @Size(max = 1)
    @NotNull
    @ColumnDefault("'N'")
    @Column(name = "DEL_YN", nullable = false, length = 1)
    private String delYn;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "CRT_DTM", nullable = false)
    private LocalDateTime crtDtm;

    @Size(max = 12)
    @NotNull
    @ColumnDefault("'SYSTEM'")
    @Column(name = "CRT_MEMB_NO", nullable = false, length = 12)
    private String crtMembNo;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "CHG_DTM", nullable = false)
    private LocalDateTime chgDtm;

    @Size(max = 12)
    @NotNull
    @ColumnDefault("'SYSTEM'")
    @Column(name = "CHG_MEMB_NO", nullable = false, length = 12)
    private String chgMembNo;

}