package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnStndMasterDto;
import com.bankle.common.entity.TbWoTrnStndMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TbWoTrnStndMasterMapper extends DefaultMapper<TbWoTrnStndMasterDto, TbWoTrnStndMaster> {
    TbWoTrnStndMasterMapper INSTANCE = Mappers.getMapper(TbWoTrnStndMasterMapper.class);
}