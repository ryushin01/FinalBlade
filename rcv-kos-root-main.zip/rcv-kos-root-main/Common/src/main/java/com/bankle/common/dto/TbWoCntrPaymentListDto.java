package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoCntrPaymentList}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbWoCntrPaymentListDto implements Serializable {
    TbWoCntrPaymentListIdDto id;
    @Size(max = 2)
    String payCd;
    @Size(max = 2)
    String statCd;
    @Size(max = 3)
    String bankCd;
    BigDecimal payAmt;
    @Size(max = 8)
    String payReqDt;
    @Size(max = 8)
    String payCmplDt;
    LocalDateTime rcptRegDtm;
    LocalDateTime rcptBnkTransDtm;
    @Size(max = 200)
    String gpsInfo;
    @NotNull
    @Size(max = 1)
    String delYn;
    @NotNull
    LocalDateTime crtDtm;
    @NotNull
    @Size(max = 12)
    String crtMembNo;
    @NotNull
    LocalDateTime chgDtm;
    @NotNull
    @Size(max = 12)
    String chgMembNo;
}