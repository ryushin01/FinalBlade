package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbCustMaster}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbCustMasterDto implements Serializable {
    @Size(max = 12)
    String membNo;
    @NotNull
    @Size(max = 150)
    String membNm;
    @NotNull
    @Size(max = 8)
    String juminNo;
    @NotNull
    Integer sexGb;
    @NotNull
    @Size(max = 2)
    String statCd;
    @NotNull
    @Size(max = 2)
    String permCd;
    @NotNull
    @Size(max = 1)
    String reptYn;
    @Size(max = 10)
    String entrDt;
    @Size(max = 10)
    String bizNo;
    @NotNull
    @Size(max = 100)
    String pinPwd;
    @Size(max = 100)
    String patnPwd;
    @Size(max = 250)
    String fcmId;
    @NotNull
    @Size(max = 1)
    String dvceKnd;
    @NotNull
    @Size(max = 150)
    String cphnNo;
    @NotNull
    @Size(max = 100)
    String diKey;
    @NotNull
    @Size(max = 100)
    String ciKey;
    @NotNull
    Integer lognFailCnt;
    Long imgSeq;
    @NotNull
    @Size(max = 1)
    String trregPssbYn;
    @NotNull
    @Size(max = 20)
    String kosAppVr;
    @NotNull
    @Size(max = 12)
    String dvceUnqNum;
    LocalDateTime mycasePgDtm;
    @Size(max = 1)
    String staffAprvStbyAlmYn;
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
}